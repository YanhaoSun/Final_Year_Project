package org.fog.placement;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Random;

import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.application.AppEdge;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.entities.FogDevice;
import org.fog.mobilitydata.Location;
import org.fog.mobilitydata.DataParser;
import org.fog.mobilitydata.References;
import org.fog.utils.Config;

public class LocationHandler {

	public DataParser dataObject;
	public Map<Integer, String> instanceToDataId;

	public Double latencyThreshold = 2.0;

	public Map<String, FogDevice> dataIdToDevice;


	public Double loadBalanceTime = 0.0;

	public Double clusterHeaderResponseTime = 0.0;

	public Double newParentResponseTime = 0.0;


	public LocationHandler(DataParser dataObject) {
		// TODO Auto-generated constructor stub
		this.dataObject = dataObject;
		instanceToDataId = new HashMap<Integer, String>();
		dataIdToDevice = new HashMap<String, FogDevice>();
	}

	public LocationHandler() {
		// TODO Auto-generated constructor stub

	}

	public DataParser getDataObject(){
		return dataObject;
	}

	public static double calculateDistance(Location loc1, Location loc2) {

		final int R = 6371; // Radius of the earth in Kilometers

		double latDistance = Math.toRadians(loc1.latitude - loc2.latitude);
		double lonDistance = Math.toRadians(loc1.longitude - loc2.longitude);
		double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
				+ Math.cos(Math.toRadians(loc1.latitude)) * Math.cos(Math.toRadians(loc2.latitude))
				* Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
		double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
		double distance = R * c; // kms


		distance = Math.pow(distance, 2);

		return Math.sqrt(distance);
	}

	//	public double calculateModuleTotalCpuLoad(){
//
//	}
	public Map<FogDevice, Double> determineCandidateParentsWithLoadBalance(ModulePlacementMobileEdgewardsCluster modulePlacementMobileEdgewardsCluster, Application application, FogDevice preParent, FogDevice user, int resourceId, FogDevice clusterHeader, List<String> preParentMigratingModules, double totalCpuLoad) {
		double deviceResponseTime = 0.0;
		double single_device_collection_time = 0.04;
		double totalTime = 0.0;
		Random random = new Random();


		long totalModuleSize = 0;
		int totalModuleRam = 0;
		long totalModuleBw = 0;

		long candidateSize = 0;
		int candidateRam = 0;
		long candidateBw = 0;
		List<FogDevice> candidateNewParentList = new ArrayList<>();
		Map<FogDevice, Double> candidateNewParentListWithLatency = new HashMap<>();
		for (String moduleName: preParentMigratingModules){
			AppModule tempModule = application.getModuleByName(moduleName);
			totalModuleSize += tempModule.getSize();
			totalModuleRam += tempModule.getRam();
			totalModuleBw += tempModule.getBw();
		}
		System.out.println("============== resources needed by modules ==================");

		System.out.println("totalCpuLoad of modules = "+totalCpuLoad);
		System.out.println("totalModuleSize of modules = "+totalModuleSize);
		System.out.println("totalModuleRam of modules = "+totalModuleRam);
		System.out.println("totalModuleBw of modules = "+totalModuleBw);
		String clusterHeaderDataId = getDataIdByInstanceID(clusterHeader.getId());
		Location clusterHeaderLoc = getResourceLocationInfo(clusterHeaderDataId);

		for (Map.Entry<FogDevice, Map<String, Object>> clusterMemberResourceInformation: clusterHeader.getClusterMemberResourceInformation().entrySet()){
			FogDevice candidateDevice = clusterMemberResourceInformation.getKey();
			double candidateOccupiedCpuLoad = modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(candidateDevice.getId());
			double candidateCpuLoad = candidateDevice.getHost().getTotalMips() - candidateOccupiedCpuLoad;
			for (String resourceType: clusterMemberResourceInformation.getValue().keySet()){
				switch (resourceType){
					case "SIZE":
						candidateSize = (long)clusterMemberResourceInformation.getValue().get(resourceType);
						break;
					case "RAM":
						candidateRam = (int)clusterMemberResourceInformation.getValue().get(resourceType);
						break;
					case "BW":
						candidateBw = (long)clusterMemberResourceInformation.getValue().get(resourceType);
						break;
					default:
						break;
				}
			}
			double randomNumber = 0.1 + (0.5 - 0.3) * random.nextDouble();
			String candidateDataId = getDataIdByInstanceID(candidateDevice.getId());
			Location candidateLoc = getResourceLocationInfo(candidateDataId);
			deviceResponseTime = randomNumber * calculateDistance(clusterHeaderLoc, candidateLoc);
			totalTime += deviceResponseTime;
			if (Objects.equals(candidateDevice.getName(), preParent.getName())){
				long sizeOccupied = 1000000 - candidateSize;
				int ramOccupied = candidateDevice.getHost().getRam() - candidateRam;
				long bwOccupied = candidateDevice.getHost().getBw() - candidateBw;
				double cpuLoadOccupied = candidateDevice.getHost().getTotalMips() - candidateCpuLoad;
				double candidateLatency = calculateLatencyOfNode(candidateDevice, user, CloudSim.clock(), cpuLoadOccupied, sizeOccupied, ramOccupied, bwOccupied);
				System.out.println("============== candidate parent device <"+candidateDevice.getName()+"> from cluster ==================");
				System.out.println("candidateCpuLoad of candidate = "+candidateCpuLoad);
				System.out.println("candidateSize of candidate = "+candidateSize);
				System.out.println("candidateRam of candidate = "+candidateRam);
				System.out.println("candidateBw of candidate = "+candidateBw);
				System.out.println("candidateLatency of candidate = "+candidateLatency);
				candidateNewParentListWithLatency.put(candidateDevice, candidateLatency);
				totalTime += single_device_collection_time;
			} else {
				if (candidateCpuLoad>=totalCpuLoad && candidateSize>=totalModuleSize && candidateRam>=totalModuleRam && candidateBw>=totalModuleBw){
					long sizeOccupied = (1000000 - candidateSize)+totalModuleSize;
					int ramOccupied = (candidateDevice.getHost().getRam() - candidateRam)+totalModuleRam;
					long bwOccupied = (candidateDevice.getHost().getBw() - candidateBw)+totalModuleBw;
					double cpuLoadOccupied = (candidateDevice.getHost().getTotalMips() - candidateCpuLoad)+totalCpuLoad;

					double candidateLatency = calculateLatencyOfNode(candidateDevice, user, CloudSim.clock(), cpuLoadOccupied, sizeOccupied, ramOccupied, bwOccupied);
					System.out.println("============== candidate parent device <"+candidateDevice.getName()+"> from cluster ==================");
					System.out.println("candidateCpuLoad of candidate = "+candidateCpuLoad);
					System.out.println("candidateSize of candidate = "+candidateSize);
					System.out.println("candidateRam of candidate = "+candidateRam);
					System.out.println("candidateBw of candidate = "+candidateBw);
					System.out.println("candidateLatency of candidate = "+candidateLatency);
					candidateNewParentListWithLatency.put(candidateDevice, candidateLatency);
					totalTime += single_device_collection_time;
				}
			}
		}
		this.setLoadBalanceTime(totalTime);
		return candidateNewParentListWithLatency;
	}
	public double calculateLatencyOfNode(FogDevice candidateDevice, FogDevice user, double time, double cpuLoadOccupied, long sizeOccupied, int ramOccupied, long bwOccupied){
		double weightRam = 0.64;
		double weightDistance = 0.2;
		double weightCpu = 0.6;
		double weightStorageSize = 0.08;
		double weightBw = 0.1;
		double candidateDistance = calculateDelayFactor(candidateDevice.getId(), user.getId(), time);

		double occupiedCpuLoadRatio = cpuLoadOccupied/candidateDevice.getHost().getTotalMips();
		long occupiedSizeRatio = sizeOccupied/candidateDevice.getHost().getStorage();
		int occupiedRamRatio = ramOccupied/candidateDevice.getHost().getRam();
		long occupiedBwRatio = bwOccupied/candidateDevice.getHost().getBw();

		// The longest distance from cloud to the gateWayNode is 943 meters(only in my test)
		candidateDistance = candidateDistance*40;
		double loadMetrics = weightCpu*occupiedCpuLoadRatio + weightStorageSize*occupiedSizeRatio + weightRam*occupiedRamRatio + weightBw*occupiedBwRatio + weightDistance*candidateDistance;
		return 0.1*(1+loadMetrics);
	}

	public double calculateDelayFactor(int gateWayNodeId, int commonAncestorId, double time){
		Location gateWayNodeLoc;
		String gateWayNodeDataId = getDataIdByInstanceID(gateWayNodeId);
		gateWayNodeLoc = getResourceLocationInfo(gateWayNodeDataId);
		String commonAncestorDataId = getDataIdByInstanceID(commonAncestorId);
		int resourceLevel=getDataObject().resourceAndUserToLevel.get(commonAncestorDataId);
		if(resourceLevel!=getDataObject().levelID.get("User")){
			Location resourceLocation;
			resourceLocation = getResourceLocationInfo(commonAncestorDataId);
			double distance = calculateDistance(gateWayNodeLoc, resourceLocation);
			return distance;
		} else {
			Location userLoc;
			userLoc = getUserLocationInfo(commonAncestorDataId,time);
			double distance = calculateDistance(gateWayNodeLoc, userLoc);
			return distance;
		}



	}
	public int determineClusterHeader(FogDevice fogDevice, int resourceId, double time) {
		// TODO Auto-generated method stub
		// resourceId是当前的deviceId
		String dataId = getDataIdByInstanceID(resourceId);
		// 如果只有一个user, 当是user device的时候, resourceId = 3, dataId = usr_1
//		System.out.println("resourceId = "+resourceId);
//		System.out.println("dataId = "+dataId);
		double deviceResponseTime = 0.0;

		// resourceAndUserToLevel存储resources和其对应的levels
		int resourceLevel=getDataObject().resourceAndUserToLevel.get(dataId);
		int parentLevel = resourceLevel-1;
		Location resourceLoc;
		// getResourceLocationInfo返回resourceLocationData, resourceLocationData存储resources和其对应的location
		// 如果当前的资源level不是 user level, 也就是说当前的resource(device)不是用户的话
		if(resourceLevel!=getDataObject().levelID.get("User"))
			// 拿到 device的location
			resourceLoc = getResourceLocationInfo(dataId);
		else
			// 如果当前的资源level是 user level, 那么根据时间和dataId拿到user device的location
			// 这个time存储的是user移动前的那个时间点和移动后的那个时间点
			resourceLoc = getUserLocationInfo(dataId,time);
		// 如果user移动了一次，那么移动前与移动后就是两个location, 分别都有一个时间, 那么就会得到两个 resourceLoc, 以此类推
//		System.out.println("resourceLoc测试 = "+resourceLoc.latitude+", "+resourceLoc.longitude);
		int parentInstanceId = References.NOT_SET;
		String parentDataId = "";


		if(time<References.INIT_TIME){
//			System.out.println("time = "+time);
//			System.out.println("References.INIT_TIME = "+References.INIT_TIME);
//			System.out.println("enter time <");
			for(int i=0; i<getLevelWiseResources(parentLevel).size();i++){
				Location potentialParentLoc = getResourceLocationInfo(getLevelWiseResources(parentLevel).get(i));
				if(potentialParentLoc.block==resourceLoc.block) {
					parentDataId = getLevelWiseResources(parentLevel).get(i);
					for(int parentIdIterator: instanceToDataId.keySet())
					{
						if(instanceToDataId.get(parentIdIterator).equals(parentDataId))
						{
							parentInstanceId = parentIdIterator;
						}
					}
				}
			}
		}
		else
		{
			double minmumDistance = Config.MAX_VALUE;
			Random random = new Random();
			for(int i=0; i<getLevelWiseResources(parentLevel).size();i++){
				// 拿到parentLevel上的每个device的位置, 暂时叫做 potentialParentLoc, 分别是res_2, res_3, res_4的location
				Location potentialParentLoc = getResourceLocationInfo(getLevelWiseResources(parentLevel).get(i));
				// 拿到每个potential parent的dataId
//				String potentialParentDataId = getLevelWiseResources(parentLevel).get(i);
				// 通过parentDataId拿到每个parentDevice
//				FogDevice potentialParentDevice = dataIdToDevice.get(potentialParentDataId);
				// 然后计算当前device和parent device的距离
				double distance = calculateDistance(resourceLoc, potentialParentLoc);
				double randomNumber = 0.1 + (0.5 - 0.3) * random.nextDouble();
				deviceResponseTime += randomNumber * distance;
				// 然后拿到当前parent到当前fogDevice的latency
//				double latency = potentialParentDevice.getChildToLatencyMap().get(fogDevice.getId());
				// 直到找到距离当前device最短 并且 latency没有超过 Threshold 的parent device
				if(distance<minmumDistance){
					parentDataId = getLevelWiseResources(parentLevel).get(i);
					minmumDistance = distance;
				}

			}
//			for (Map.Entry<Integer, String> ins: instanceToDataId.entrySet()){
//				System.out.println("ins.key = "+ins.getKey());
//				System.out.println("ins.value = "+ins.getValue());
//			}
			for(int parentIdIterator: instanceToDataId.keySet())
			{
				if(instanceToDataId.get(parentIdIterator).equals(parentDataId))
				{
					parentInstanceId = parentIdIterator;
				}
			}

		}
		this.setClusterHeaderResponseTime(deviceResponseTime);
		return parentInstanceId;
	}

	public int determineParent(int resourceId, double time) {
		// TODO Auto-generated method stub
		// resourceId是当前的deviceId
		String dataId = getDataIdByInstanceID(resourceId);
		double deviceResponseTime = 0.0;
		// 因为目前只有一个user, 所以当是user device的时候, resourceId = 3, dataId = usr_1
//		System.out.println("resourceId = "+resourceId);
//		System.out.println("dataId = "+dataId);
		// resourceAndUserToLevel存储resources和其对应的levels
		int resourceLevel=getDataObject().resourceAndUserToLevel.get(dataId);
		int parentLevel = resourceLevel-1;
		Location resourceLoc;
		// getResourceLocationInfo返回resourceLocationData, resourceLocationData存储resources和其对应的location
		// 如果当前的资源level不是 user level, 也就是说当前的resource(device)不是用户的话
		if(resourceLevel!=getDataObject().levelID.get("User"))
			// 拿到 device的location
			resourceLoc = getResourceLocationInfo(dataId);
		else
			// 如果当前的资源level是 user level, 那么根据时间和dataId拿到user device的location
			resourceLoc = getUserLocationInfo(dataId,time);

		int parentInstanceId = References.NOT_SET;
		String parentDataId = "";


		if(time<References.INIT_TIME){
//			System.out.println("time = "+time);
//			System.out.println("References.INIT_TIME = "+References.INIT_TIME);
//			System.out.println("enter time <");
			for(int i=0; i<getLevelWiseResources(parentLevel).size();i++){
				Location potentialParentLoc = getResourceLocationInfo(getLevelWiseResources(parentLevel).get(i));
				if(potentialParentLoc.block==resourceLoc.block) {
					parentDataId = getLevelWiseResources(parentLevel).get(i);
					for(int parentIdIterator: instanceToDataId.keySet())
					{
						if(instanceToDataId.get(parentIdIterator).equals(parentDataId))
						{
							parentInstanceId = parentIdIterator;
						}
					}
				}
			}
		}
		else
		{
			double minmumDistance = Config.MAX_VALUE;
			Random random = new Random();
			for(int i=0; i<getLevelWiseResources(parentLevel).size();i++){
				// 拿到parentLevel上的每个device的位置, 暂时叫做 potentialParentLoc
				Location potentialParentLoc = getResourceLocationInfo(getLevelWiseResources(parentLevel).get(i));
				// 然后计算当前device和parent device的距离
				double distance = calculateDistance(resourceLoc, potentialParentLoc);
				if (time!=0.0){
					double randomNumber = 0.1 + (0.5 - 0.3) * random.nextDouble();
					deviceResponseTime += randomNumber * distance;
				}
				// 直到找到距离当前device最短的parent device
				if(distance<minmumDistance){
					parentDataId = getLevelWiseResources(parentLevel).get(i);
					minmumDistance = distance;
				}
			}
//			for (Map.Entry<Integer, String> ins: instanceToDataId.entrySet()){
//				System.out.println("ins.key = "+ins.getKey());
//				System.out.println("ins.value = "+ins.getValue());
//			}
			for(int parentIdIterator: instanceToDataId.keySet())
			{
				if(instanceToDataId.get(parentIdIterator).equals(parentDataId))
				{
					parentInstanceId = parentIdIterator;
				}
			}

		}
		this.setNewParentResponseTime(deviceResponseTime);
		return parentInstanceId;
	}

	private Location getUserLocationInfo(String dataId, double time) {
		// TODO Auto-generated method stub
		return getDataObject().usersLocation.get(dataId).get(time);
	}

	private Location getResourceLocationInfo(String dataId) {
		// TODO Auto-generated method stub
		return getDataObject().resourceLocationData.get(dataId);
	}

	public List<Double> getTimeSheet(int instanceId) {

		String dataId = getDataIdByInstanceID(instanceId);
		List<Double>timeSheet = new ArrayList<Double>(getDataObject().usersLocation.get(dataId).keySet());
		return timeSheet;
	}

	public void linkDataWithInstance(int instanceId, String dataID) {
		// TODO Auto-generated method stub
		instanceToDataId.put(instanceId, dataID);
	}
	public void linkDataIdWithDevice(String dataID, FogDevice fogDevice) {
		// TODO Auto-generated method stub
		dataIdToDevice.put(dataID, fogDevice);
	}
	public int getLevelID(String resourceType) {
		// TODO Auto-generated method stub
		return dataObject.levelID.get(resourceType);
	}

	public ArrayList<String> getLevelWiseResources(int levelNo) {
		// TODO Auto-generated method stub
		return getDataObject().levelwiseResources.get(levelNo);
	}

	public void parseUserInfo(Map<Integer, Integer> userMobilityPattern, String datasetReference) throws IOException {
		// TODO Auto-generated method stub
		getDataObject().parseUserData(userMobilityPattern, datasetReference);
	}

	public void parseResourceInfo() throws NumberFormatException, IOException {
		// TODO Auto-generated method stub
		getDataObject().parseResourceData();
	}

	public List<String> getMobileUserDataId() {
		// TODO Auto-generated method stub
		List<String> userDataIds = new ArrayList<>(getDataObject().usersLocation.keySet());
		return userDataIds;

	}

	public Map<String, Integer> getDataIdsLevelReferences() {
		// TODO Auto-generated method stub
		return getDataObject().resourceAndUserToLevel;
	}

	public boolean isCloud(int instanceID) {
		// TODO Auto-generated method stub
		String dataId = getDataIdByInstanceID(instanceID);
		int instenceLevel=getDataObject().resourceAndUserToLevel.get(dataId);
		if(instenceLevel==getDataObject().levelID.get("Cloud"))
			return true;
		else
			return false;
	}

	public Double getLoadBalanceTime() {
		return loadBalanceTime;
	}

	public void setLoadBalanceTime(Double loadBalanceTime) {
		this.loadBalanceTime = loadBalanceTime;
	}

	public Double getNewParentResponseTime() {
		return newParentResponseTime;
	}

	public void setNewParentResponseTime(Double newParentResponseTime) {
		this.newParentResponseTime = newParentResponseTime;
	}

	public Double getClusterHeaderResponseTime() {
		return clusterHeaderResponseTime;
	}

	public void setClusterHeaderResponseTime(Double clusterHeaderResponseTime) {
		this.clusterHeaderResponseTime = clusterHeaderResponseTime;
	}

	public String getDataIdByInstanceID(int instanceID) {
		// TODO Auto-generated method stub
		return instanceToDataId.get(instanceID);
	}

	public Map<Integer, String> getInstenceDataIdReferences() {
		// TODO Auto-generated method stub
		return instanceToDataId;
	}

	public boolean isAMobileDevice(int instanceId) {
		// TODO Auto-generated method stub
		String dataId = getDataIdByInstanceID(instanceId);
		int instenceLevel=getDataObject().resourceAndUserToLevel.get(dataId);
		if(instenceLevel==getDataObject().levelID.get("User"))
			return true;
		else
			return false;
	}
}
