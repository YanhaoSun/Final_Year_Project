package org.fog.placement;

import org.apache.commons.math3.util.Pair;
import org.fog.application.AppEdge;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.entities.FogDevice;
import org.fog.entities.Tuple;
import org.fog.entities.ControllerComponent;
import org.fog.entities.MicroserviceFogDevice;
import org.fog.entities.PlacementRequest;
import org.fog.utils.Logger;
import org.fog.utils.ModuleLaunchConfig;

import java.util.*;

/**
 * Created by Samodha Pallewatta on 5/27/2021.
 */
public class ClusteredMicroservicePlacementLogic implements MicroservicePlacementLogic {
    /**
     * Fog network related details
     */
    List<FogDevice> fogDevices; //fog devices considered by FON for placements of requests
    List<PlacementRequest> placementRequests; // requests to be processed
    protected Map<Integer, Map<String, Double>> resourceAvailability;
    private Map<String, Application> applicationInfo = new HashMap<>();
    private Map<String, String> moduleToApp = new HashMap<>();

    int fonID;

    protected Map<Integer, Double> currentCpuLoad;
    protected Map<Integer, List<String>> currentModuleMap = new HashMap<>();
    protected Map<Integer, Map<String, Double>> currentModuleLoadMap = new HashMap<>();
    protected Map<Integer, Map<String, Integer>> currentModuleInstanceNum = new HashMap<>();

    Map<Integer, Map<String, Integer>> mappedMicroservices = new HashMap<>();
    ; //mappedMicroservice

    public ClusteredMicroservicePlacementLogic(int fonID) {
        setFONId(fonID);
    }

    public void setFONId(int id) {
        fonID = id;
    }

    public int getFonID() {
        return fonID;
    }

    @Override
    public PlacementLogicOutput run(List<FogDevice> fogDevices, Map<String, Application> applicationInfo, Map<Integer, Map<String, Double>> resourceAvailability, List<PlacementRequest> pr) {
        this.fogDevices = fogDevices;
        this.placementRequests = pr;
        this.resourceAvailability = resourceAvailability;
        this.applicationInfo = applicationInfo;

        setCurrentCpuLoad(new HashMap<Integer, Double>());
        setCurrentModuleMap(new HashMap<>());
        for (FogDevice dev : fogDevices) {
            // 每个设备的CPU负载
            getCurrentCpuLoad().put(dev.getId(), 0.0);
            // 每个设备的所有modules
            getCurrentModuleMap().put(dev.getId(), new ArrayList<>());
            // 每个设备上每个module所对应的负载
            currentModuleLoadMap.put(dev.getId(), new HashMap<String, Double>());
            // 每个设备上每个module的实例数量
            currentModuleInstanceNum.put(dev.getId(), new HashMap<String, Integer>());
        }

        mapModules();
        PlacementLogicOutput placement = generatePlacementMap();
        // 更新每个device中的cpu, storage, ram的可用资源的数量
        updateResources(resourceAvailability);
//        System.out.println("before postProcessing()");
        postProcessing();
        return placement;
    }

    @Override
    public void updateResources(Map<Integer, Map<String, Double>> resourceAvailability) {
        // resourceAvailability 存储的是每个device中, cpu, storage, ram的可用资源数量
//        System.out.println("||||| 打印resourceAvailability: |||||");
//        for (Map.Entry<Integer, Map<String, Double>> m : resourceAvailability.entrySet()) {
//            System.out.println("resourceAvailability.getKey() = "+m.getKey());
//            for(Map.Entry<String, Double> n: m.getValue().entrySet()){
//                System.out.println("       resourceAvailability.getValue().getKey() = "+n.getKey());
//                System.out.println("       resourceAvailability.getValue().getKey().getValue() = "+n.getValue());
//            }
//        }
        for (int deviceId : currentModuleInstanceNum.keySet()) {
            Map<String, Integer> moduleCount = currentModuleInstanceNum.get(deviceId);
            for (String moduleName : moduleCount.keySet()) {
                Application app = applicationInfo.get(moduleToApp.get(moduleName));
                AppModule module = app.getModuleByName(moduleName);
                double mips = resourceAvailability.get(deviceId).get(ControllerComponent.CPU) - (module.getMips() * moduleCount.get(moduleName));
                resourceAvailability.get(deviceId).put(ControllerComponent.CPU, mips);
            }
        }
    }

    private PlacementLogicOutput generatePlacementMap() {
        Map<Integer, Map<String, Integer>> placement = new HashMap<>();
        System.out.println("**************在 method generatePlacementMap 内部: **************");
        System.out.println("*****打印placementRequests: *****");
        for(PlacementRequest p: placementRequests){
            System.out.println("p.getGatewayDeviceId() = "+p.getGatewayDeviceId());
            System.out.println("p.getPlacedMicroservices() = "+p.getPlacedMicroservices());
        }
        System.out.println("*****打印mappedMicroservices: *****");
        for (Map.Entry<Integer, Map<String, Integer>> m : mappedMicroservices.entrySet()) {
            System.out.println("m.placementRequest ID = "+m.getKey());
            for(Map.Entry<String, Integer> n: m.getValue().entrySet()){
                System.out.println("       当前PR已经部署的modules = "+n.getKey());
                System.out.println("       当前PR已经部署的modules所在的设备 = "+n.getValue());
            }
        }
        // 这个 for loop 把所有已经部署的 microservices 都加入 placementRequest
        // 然后移除掉 mappedMicroservices 中每个 PR 里面的 clientModule
        for (PlacementRequest placementRequest : placementRequests) {
            List<String> toRemove = new ArrayList<>();
            // 下面这个方法的for loop取的是已经被部署的microServices
            //placement should include newly placed ones
            for (String microservice : mappedMicroservices.get(placementRequest.getPlacementRequestId()).keySet()) {
                if (placementRequest.getPlacedMicroservices().containsKey(microservice))
                    toRemove.add(microservice);
                else
                    placementRequest.getPlacedMicroservices().put(microservice, mappedMicroservices.get(placementRequest.getPlacementRequestId()).get(microservice));
            }
            for (String microservice : toRemove)
                mappedMicroservices.get(placementRequest.getPlacementRequestId()).remove(microservice);

            //update placed modules in placement request as well
            placement.put(placementRequest.getPlacementRequestId(), mappedMicroservices.get(placementRequest.getPlacementRequestId()));
        }
        System.out.println("||||| after remove, 打印placementRequests: |||||");
        for(PlacementRequest p: placementRequests){
            System.out.println("p.getGatewayDeviceId() = "+p.getGatewayDeviceId());
            System.out.println("p.getPlacedMicroservices() = "+p.getPlacedMicroservices());
        }
        System.out.println("||||| after remove, 打印mappedMicroservices: |||||");
        for (Map.Entry<Integer, Map<String, Integer>> m : mappedMicroservices.entrySet()) {
            System.out.println("m.placementRequest ID = "+m.getKey());
            for(Map.Entry<String, Integer> n: m.getValue().entrySet()){
                System.out.println("       当前PR已经部署的modules = "+n.getKey());
                System.out.println("       当前PR已经部署的modules所在的设备 = "+n.getValue());
            }
        }
        System.out.println("||||| after remove, 打印placement: |||||");
        for (Map.Entry<Integer, Map<String, Integer>> p : placement.entrySet()) {
            System.out.println("m.placementRequest ID = "+p.getKey());
            for(Map.Entry<String, Integer> q: p.getValue().entrySet()){
                System.out.println("       当前PR已经部署的modules = "+q.getKey());
                System.out.println("       当前PR已经部署的modules所在的设备 = "+q.getValue());
            }
        }
        //todo it assumed that modules are not shared among applications.
        // <deviceid, < app, list of modules to deploy > this is to remove deploying same module more than once on a certain device.
        Map<Integer, Map<Application, List<ModuleLaunchConfig>>> perDevice = new HashMap<>();
        Map<Integer, List<Pair<String, Integer>>> serviceDiscoveryInfo = new HashMap<>();
        Map<PlacementRequest, Integer> prStatus = new HashMap<>();
        if (placement != null) {
            for (int prID : placement.keySet()) {
                //retrieve application
                PlacementRequest placementRequest = null;
                for (PlacementRequest pr : placementRequests) {
                    if (pr.getPlacementRequestId() == prID)
                        placementRequest = pr;
                }
                Application application = applicationInfo.get(placementRequest.getApplicationId());
                // 更新serviceDiscoveryInfo 存储: key(每个 clientDevice)  value(每个 clientDevice 可以通向的 microservice, 以及这个microservice所在的device)
                for (String microserviceName : placement.get(prID).keySet()) {
                    // 拿到当前这个microservice所在的device的ID
                    int deviceID = placement.get(prID).get(microserviceName);

                    //service discovery info propagation
                    // clientDevices保存的是所有dest为 microserviceName 的所有source microservices所在的设备的ID
                    List<Integer> clientDevices = getClientServiceNodeIds(application, microserviceName, placementRequest.getPlacedMicroservices(), placement.get(prID));
                    // serviceDiscoveryInfo 存储: key, 每个 clientDevice  value, 每个 clientDevice 可以通向的 microservice
                    for (int clientDevice : clientDevices) {
                        if (serviceDiscoveryInfo.containsKey(clientDevice))
                            serviceDiscoveryInfo.get(clientDevice).add(new Pair<>(microserviceName, deviceID));
                        else {
                            List<Pair<String, Integer>> s = new ArrayList<>();
                            s.add(new Pair<>(microserviceName, deviceID));
                            serviceDiscoveryInfo.put(clientDevice, s);
                        }
                    }
                }
                // all prs get placed in this placement algorithm
                prStatus.put(placementRequest, -1);
            }

            //todo module is created new here check if this is needed

            // currentModuleInstanceNum存储每个device上每种microServices的实例数量
            for (int deviceId : currentModuleInstanceNum.keySet()) {
                for (String microservice : currentModuleInstanceNum.get(deviceId).keySet()) {
                    Application application = applicationInfo.get(moduleToApp.get(microservice));
//                    System.out.println("microservice = "+microservice);
//                    System.out.println("application.getModuleByName(microservice) = "+application.getModuleByName(microservice).getName());
                    AppModule appModule = new AppModule(application.getModuleByName(microservice));
                    // currentModuleInstanceNum.get(deviceId).get(microservice) 表示当前 deviceId 的这个设备上的这个 microservice 的实例数量
                    ModuleLaunchConfig moduleLaunchConfig = new ModuleLaunchConfig(appModule, currentModuleInstanceNum.get(deviceId).get(microservice));
                    // perDevice存储 每个设备 以及 该设备上有的application 和 该application上面装载的modules
                    if (perDevice.keySet().contains(deviceId)) {
                        if (perDevice.get(deviceId).containsKey(application)) {
                            perDevice.get(deviceId).get(application).add(moduleLaunchConfig);
                        } else {
                            List<ModuleLaunchConfig> l = new ArrayList<>();
                            l.add(moduleLaunchConfig);
                            perDevice.get(deviceId).put(application, l);
                        }
                    } else {
                        List<ModuleLaunchConfig> l = new ArrayList<>();
                        l.add(moduleLaunchConfig);
                        HashMap<Application, List<ModuleLaunchConfig>> m = new HashMap<>();
                        m.put(application, l);
                        perDevice.put(deviceId, m);
                    }
                }
            }
        }
        // perDevice存储 每个设备 以及 该设备上有的application 和 该application上面装载的modules
        return new PlacementLogicOutput(perDevice, serviceDiscoveryInfo, prStatus);
    }

    public List<Integer> getClientServiceNodeIds(Application application, String
            microservice, Map<String, Integer> placed, Map<String, Integer> placementPerPr) {
        // 找到所有dest是microservice, 并且edge.tuple = UP 的microservices, 把这些作为clientServices
        List<String> clientServices = getClientServices(application, microservice);
        List<Integer> nodeIDs = new LinkedList<>();
        for (String clientService : clientServices) {
            // placed是当前PR中已经部署的microservices
            // if, else if均执行相同的操作, 即检查如果当前clientService已经被部署, 那么将当前部署的设备ID加入nodeIDs
            if (placed.get(clientService) != null)
                nodeIDs.add(placed.get(clientService));
            else if (placementPerPr.get(clientService) != null)
                nodeIDs.add(placementPerPr.get(clientService));
        }
        // nodeIDs保存的是所有dest为当前microservice的所有source microservices所在的设备的ID
        return nodeIDs;
    }

    public List<String> getClientServices(Application application, String microservice) {
        List<String> clientServices = new LinkedList<>();

        for (AppEdge edge : application.getEdges()) {
            if (edge.getDestination().equals(microservice) && edge.getDirection() == Tuple.UP)
                clientServices.add(edge.getSource());
        }


        return clientServices;
    }

    @Override
    public void postProcessing() {

    }

    public void setCurrentCpuLoad(Map<Integer, Double> currentCpuLoad) {
        this.currentCpuLoad = currentCpuLoad;
    }

    public Map<Integer, List<String>> getCurrentModuleMap() {
        return currentModuleMap;
    }

    public void setCurrentModuleMap(Map<Integer, List<String>> currentModuleMap) {
        this.currentModuleMap = currentModuleMap;
    }

    public void mapModules() {
        Map<PlacementRequest, Integer> deviceToPlace = new HashMap<>();
        //initiate with the  parent of the client device for this
        for(PlacementRequest p: placementRequests){
            System.out.println("p.getGatewayDeviceId() = "+p.getGatewayDeviceId());
            System.out.println("p.getPlacedMicroservices() = "+p.getPlacedMicroservices());
        }
        // placementRequest里面的placedModules 需要和 mappedMicroservices里面的value <module, placedDeviceId> 保持一致，
        // 一旦placementRequest里面的placedModules更新了，mappedMicroservices里面的value <module, placedDeviceId>也需要更新
        System.out.println("||||||||||循环每个placementRequest, 将其中的部署情况同步给mappedMicroservices, 并且将cloud, mService3添加到每个placementRequest||||||||||");
        for (PlacementRequest placementRequest : placementRequests) {
            // 因为 mobile_0 和 mobile_1 已经部署了 clientModule, 所以接下来需要部署 gateway_0 和 gateway_1 了, 所以用了getParentId(),
            // 每个req只有一个unplaced device, 只有这个被部署以后, 并且还有未部署modules, 才会继续寻找新的unplaced device
            deviceToPlace.put(placementRequest, getDevice(placementRequest.getGatewayDeviceId()).getParentId());


            // 每个placementRequest上面的modules部署情况都不一样, 可以将placementRequest理解为不同paths(leaves to root)的部署情况
            // 第一个placementRequest: {clientModule=3}, {mService3=9}
            // 第二个placementRequest: {clientModule=6}, {mService3=9}

            // already placed modules, 存储当前request ID上已经部署的modules
            // mappedMicroservices: key placementRequest, value [1st req value{clientModule=3}, 2nd req value{clientModule=6}]
            mappedMicroservices.put(placementRequest.getPlacementRequestId(), new HashMap<>(placementRequest.getPlacedMicroservices()));

            //special modules  - predefined cloud placements
            Application app =  applicationInfo.get(placementRequest.getApplicationId());

            System.out.println("***进入循环: for, 处理每个req的predefined cloud placements***");
            // 先处理每个placement Request里面app的predefined cloud placements
            // 这个for loop 循环的是在Application里面, 提前分配好的 cloud --- microservice3, 只是分配好, 还没有部署, 这里将其部署
            for (String microservice : app.getSpecialPlacementInfo().keySet()) {
                System.out.println("getSpecialPlacementInfo = "+microservice);
                for (String deviceName : app.getSpecialPlacementInfo().get(microservice)) {
                    // 这里, 得到的device 就是 cloud
                    FogDevice device = getDeviceByName(deviceName);
                    int deviceId = device.getId();

                    // 如果当前module的负载 + 当前设备的负载 <= 当前设备的CPU的资源负载, 也就是说检查当前设备能否负担得起这个module
                    if (getModule(microservice, app).getMips() + getCurrentCpuLoad().get(deviceId) <= resourceAvailability.get(deviceId).get(ControllerComponent.CPU)) {
                        Logger.debug("ModulePlacementEdgeward", "Placement of operator " + microservice + " on device " + device.getName() + " successful.");
                        getCurrentCpuLoad().put(deviceId, getModule(microservice, app).getMips() + getCurrentCpuLoad().get(deviceId));
                        System.out.println("Placement of operator " + microservice + " on device " + device.getName() + " successful.");

                        // 把被部署的module和这个module所属的app存储起来
                        moduleToApp.put(microservice, app.getAppId());
                        // 将部署的modules加入被部署的device, currentModuleMap 存储: microservices each device has
                        if (!currentModuleMap.get(deviceId).contains(microservice))
                            currentModuleMap.get(deviceId).add(microservice);
                        // 将当前placementRequest与被部署的module(mService3)和部署的device(cloud)联系起来
                        // 将 key placementRequest  value {microservice3=9} 放进 mappedMicroservices, 对每个placementRequest都这么做
                        // mappedMicroservices存储当前PR已经部署的microservice以及部署到哪个device上了
                        mappedMicroservices.get(placementRequest.getPlacementRequestId()).put(microservice, deviceId);
//                        System.out.println("mappedMicroservices.get(placementRequest.getPlacementRequestId())"+mappedMicroservices.get(placementRequest.getPlacementRequestId()));
                        //currentModuleLoad, 将 当前设备上 与 当前设备这个module以及该module的负载联系起来
                        if (!currentModuleLoadMap.get(deviceId).containsKey(microservice))
                            currentModuleLoadMap.get(deviceId).put(microservice, getModule(microservice, app).getMips());
                        else
                            currentModuleLoadMap.get(deviceId).put(microservice, getModule(microservice, app).getMips() + currentModuleLoadMap.get(deviceId).get(microservice));


                        //currentModuleInstance, 存储目前设备上该module的实例数量
                        if (!currentModuleInstanceNum.get(deviceId).containsKey(microservice))
                            currentModuleInstanceNum.get(deviceId).put(microservice, 1);
                        else
                            currentModuleInstanceNum.get(deviceId).put(microservice, currentModuleInstanceNum.get(deviceId).get(microservice) + 1);

                        break;
                    }
                }
            }
            System.out.println("***循环: for, 处理每个req的predefined cloud placements 结束***");
        }
        System.out.println("\n||||||||||special modules 在cloud上面的部署完成, 第一个循环for结束||||||||||\n");

        System.out.println("打印每个PlacementRequest需要部署的device");
        for(Map.Entry<PlacementRequest, Integer> m : deviceToPlace.entrySet()){
            System.out.println("device to place = "+m.getValue());
        }
        System.out.println();
        Map<PlacementRequest, Integer> clusterNode = new HashMap<>();

        Map<PlacementRequest, List<String>> toPlace = new HashMap<>();

        int placementCompleteCount = 0;
        System.out.println("||||||||||进入第二个循环: while||||||||||");
        int count = 0;
        while (placementCompleteCount < placementRequests.size()) {
            count ++;
            System.out.println("while loop: "+count);
            // 将每个placementRequest中还需要部署的modules加入到 toPlace 中, method getModulesToPlace 会把req中已经部署了的modules进行过滤,
            // 从而找到还需要部署的modules
            if (toPlace.isEmpty()) {
                System.out.println("***循环for loop, 寻找toPlace: 找到每个placementRequest还需要部署的modules, 第一次是up, 第二次是down, 所以导致第一次modules to place都是mService1, 第二次都是mService2***");
                for (PlacementRequest placementRequest : placementRequests) {
                    System.out.println();
                    Application app = applicationInfo.get(placementRequest.getApplicationId());
                    System.out.println("mappedMicroservices.get(placementRequest.getPlacementRequestId())"+mappedMicroservices.get(placementRequest.getPlacementRequestId()));

                    List<String> modulesToPlace = getModulesToPlace(mappedMicroservices.get(placementRequest.getPlacementRequestId()).keySet(), app);
                    for(String m: modulesToPlace){
                        System.out.println("modules to place: "+m);
                    }
                    if (modulesToPlace.isEmpty())
                        placementCompleteCount++;
                    else
                        toPlace.put(placementRequest, modulesToPlace);
                }
                System.out.println("***循环for loop, 寻找toPlace 结束***");
            }
            System.out.println("toPlace(key: placementRequest, value: 每个req需要部署的modules)   寻找完成");

            for(Map.Entry<PlacementRequest, List<String>> a: toPlace.entrySet()){
                System.out.println("placementREQ: "+a.getKey().getPlacementRequestId());
                System.out.println("modules to place: "+a.getValue().toString());
            }
            System.out.println("\n***循环req, 并开始为没有部署modules的每个device部署modules, 循环所有req***");
            for (PlacementRequest placementRequest : placementRequests) {
                Application app = applicationInfo.get(placementRequest.getApplicationId());
                int deviceId = deviceToPlace.get(placementRequest);
                // if not cluster
                if (deviceId != -1) {
                    FogDevice device = getDevice(deviceId);
                    List<String> placed = new ArrayList<>();
                    if(toPlace.isEmpty()){
                        System.out.println("第三次while循环");
                        System.out.println("deviceID = "+deviceId);
                    }
                    //也就是说如果当前这个req还有未被部署的modules的话, 进入if statement
                    if (toPlace.containsKey(placementRequest)) {
                        for (String microservice : toPlace.get(placementRequest)) {
                            // try to place
                            if (getModule(microservice, app).getMips() + getCurrentCpuLoad().get(deviceId) <= resourceAvailability.get(deviceId).get(ControllerComponent.CPU)) {
                                Logger.debug("ModulePlacementEdgeward", "Placement of operator " + microservice + " on device " + device.getName() + " successful.");
                                getCurrentCpuLoad().put(deviceId, getModule(microservice, app).getMips() + getCurrentCpuLoad().get(deviceId));
                                System.out.println("Placement of operator " + microservice + " on device " + device.getName() + " successful."+"没有集群");

                                moduleToApp.put(microservice, app.getAppId());

                                if (!currentModuleMap.get(deviceId).contains(microservice))
                                    currentModuleMap.get(deviceId).add(microservice);

                                mappedMicroservices.get(placementRequest.getPlacementRequestId()).put(microservice, deviceId);

                                //currentModuleLoad
                                if (!currentModuleLoadMap.get(deviceId).containsKey(microservice))
                                    currentModuleLoadMap.get(deviceId).put(microservice, getModule(microservice, app).getMips());
                                else
                                    currentModuleLoadMap.get(deviceId).put(microservice, getModule(microservice, app).getMips() + currentModuleLoadMap.get(deviceId).get(microservice));


                                //currentModuleInstance
                                if (!currentModuleInstanceNum.get(deviceId).containsKey(microservice))
                                    currentModuleInstanceNum.get(deviceId).put(microservice, 1);
                                else
                                    currentModuleInstanceNum.get(deviceId).put(microservice, currentModuleInstanceNum.get(deviceId).get(microservice) + 1);

                                // 将被部署的microservice加入placed
                                placed.add(microservice);
                            }
                        }
                        // 从toPlace中移除已经被部署的module
                        for (String m : placed) {
                            toPlace.get(placementRequest).remove(m);
                        }
                        // 如果当前req还有modules没有部署的话, 我们需要parent of current device, 这样做的目的是将更多的modules
                        // 继续往上部署
                        if (!toPlace.get(placementRequest).isEmpty()) {
                            //TODO: 如果检测到是集群部署, 是否可以在这里进行 cluster load balance?
                            //这里检查当前device是否是cluster node(我们在modules部署之前已经进行了集群处理, 所以这里直接检测就好)
                            if (((MicroserviceFogDevice) device).getIsInCluster()) {
                                // -1 indicates it's a cluster placement
                                deviceToPlace.put(placementRequest, -1);
                                // a device of the cluster to identify the cluster
                                clusterNode.put(placementRequest, deviceId);
                            } else {
                                deviceToPlace.put(placementRequest, device.getParentId());
                            }
                        }
                        // 如果当前req中未部署的modules已经全部部署, 那么就可以移除这个req了
                        if (toPlace.get(placementRequest).isEmpty())
                            toPlace.remove(placementRequest);
                    }
                }
                // 如果是cluster
                // (暂时不会进入这个else)
                else {
                    System.out.println("***if the device is in cluster***");
                    if (toPlace.containsKey(placementRequest)) {
                        int clusterDeviceId = clusterNode.get(placementRequest);
                        FogDevice device = getDevice(clusterDeviceId);
                        // 拿到当前device的所有集群成员
                        List<Integer> clusterDeviceIds = ((MicroserviceFogDevice) device).getClusterMembers();
                        List<Integer> sortedClusterDevicesActive = new ArrayList<>();
                        List<Integer> sortedClusterDevicesInactive = new ArrayList<>();
                        for (Integer id : clusterDeviceIds) {
                            //sort list from min to max
                            if (currentModuleMap.get(id).size()>0 && sortedClusterDevicesActive.isEmpty())
                                sortedClusterDevicesActive.add(id);
                            else if(currentModuleMap.get(id).size()==0 && sortedClusterDevicesInactive.isEmpty())
                                sortedClusterDevicesInactive.add(id);
                            else if(currentModuleMap.get(id).size()>0){
                                boolean isPlaced = false;
                                for (int i = 0; i < sortedClusterDevicesActive.size(); i++) {
                                    double sorted = resourceAvailability.get(sortedClusterDevicesActive.get(i)).get("cpu") -
                                            getCurrentCpuLoad().get(sortedClusterDevicesActive.get(i));
                                    double current = resourceAvailability.get(id).get("cpu") -
                                            getCurrentCpuLoad().get(id);
                                    if (sorted < current) {
                                        sortedClusterDevicesActive.add(i, id);
                                        isPlaced = true;
                                        break;
                                    } else {
                                        continue;
                                    }
                                }
                                if (!isPlaced)
                                    sortedClusterDevicesActive.add(id);
                            }
                            else{
                                boolean isPlaced = false;
                                for (int i = 0; i < sortedClusterDevicesInactive.size(); i++) {
                                    // resourceAvailability.get(sortedClusterDevicesInactive.get(i))
                                    // 表示未启用的device上的可用的所有资源
                                    // getCurrentCpuLoad().get(i), 表示当前deviceId = i的设备上面已经被占用的资源

                                    // i表示在sortedClusterDevicesInactive中的clusteredDevice的index, sortedClusterDevicesInactive存储的是未被启用的devices
                                    double sorted = resourceAvailability.get(sortedClusterDevicesInactive.get(i)).get("cpu") -
                                            getCurrentCpuLoad().get(sortedClusterDevicesInactive.get(i));
                                    // id表示clusteredDevice的ID
                                    double current = resourceAvailability.get(id).get("cpu") -
                                            getCurrentCpuLoad().get(id);
                                    // 如果已经启用了的集群device的resources 大于 未被启用的集群device的resources
                                    if (sorted < current) {
                                        sortedClusterDevicesInactive.add(i, id);
                                        isPlaced = true;
                                        break;
                                    } else {
                                        continue;
                                    }
                                }
                                if (!isPlaced)
                                    sortedClusterDevicesInactive.add(id);
                            }
                        }

                        List<Integer> sortedClusterDevices = new ArrayList<>(sortedClusterDevicesActive);
                        sortedClusterDevices.addAll(sortedClusterDevicesInactive);
                        List<String> placed = new ArrayList<>();
                        for (String microservice : toPlace.get(placementRequest)) {
                            for (int id : sortedClusterDevices) {
                                // try to place
                                if (getModule(microservice, app).getMips() + getCurrentCpuLoad().get(id) <= resourceAvailability.get(id).get(ControllerComponent.CPU)) {
                                    FogDevice placedDevice = getDevice(id);
                                    Logger.debug("ModulePlacementEdgeward", "Placement of operator " + microservice + " on device " + placedDevice.getName() + " successful.");
                                    getCurrentCpuLoad().put(id, getModule(microservice, app).getMips() + getCurrentCpuLoad().get(id));
                                    System.out.println("Placement of operator " + microservice + " on device " + placedDevice.getName() + " successful. 有集群");

                                    if (!currentModuleMap.get(id).contains(microservice))
                                        currentModuleMap.get(id).add(microservice);

                                    mappedMicroservices.get(placementRequest.getPlacementRequestId()).put(microservice, id);

                                    moduleToApp.put(microservice, app.getAppId());

                                    //currentModuleLoad
                                    if (!currentModuleLoadMap.get(id).containsKey(microservice))
                                        currentModuleLoadMap.get(id).put(microservice, getModule(microservice, app).getMips());
                                    else
                                        currentModuleLoadMap.get(id).put(microservice, getModule(microservice, app).getMips() + currentModuleLoadMap.get(id).get(microservice));


                                    //currentModuleInstance
                                    if (!currentModuleInstanceNum.get(id).containsKey(microservice))
                                        currentModuleInstanceNum.get(id).put(microservice, 1);
                                    else
                                        currentModuleInstanceNum.get(id).put(microservice, currentModuleInstanceNum.get(id).get(microservice) + 1);

                                    placed.add(microservice);
                                    break;
                                }
                            }
                        }

                        for (String m : placed) {
                            toPlace.get(placementRequest).remove(m);
                        }
                        if (!toPlace.get(placementRequest).isEmpty()) {
                            //check
                            deviceToPlace.put(placementRequest, device.getParentId());
                        }
                        if (toPlace.get(placementRequest).isEmpty())
                            toPlace.remove(placementRequest);
                    }
                }
            }
            System.out.println("***循环req for loop结束***");
        }
        System.out.println("||||||||||循环 while 结束||||||||||");
    }

    private FogDevice getDeviceByName(String deviceName) {
        for (FogDevice f : fogDevices) {
            if (f.getName().equals(deviceName))
                return f;
        }
        return null;
    }

    public Map<Integer, Double> getCurrentCpuLoad() {
        return currentCpuLoad;
    }

    private AppModule getModule(String moduleName, Application app) {
        for (AppModule appModule : app.getModules()) {
            if (appModule.getName().equals(moduleName))
                return appModule;
        }
        return null;
    }

    private FogDevice getDevice(int deviceId) {
        for (FogDevice fogDevice : fogDevices) {
            if (fogDevice.getId() == deviceId)
                return fogDevice;
        }
        return null;
    }

    private List<String> getModulesToPlace(Set<String> placedModules, Application app) {
        for(String m: placedModules){
            System.out.println("within getModulesToPlace, placedModules: "+m);
        }
        List<String> modulesToPlace_1 = new ArrayList<String>();
        List<String> modulesToPlace = new ArrayList<String>();
        for (AppModule module : app.getModules()) {
//            System.out.println("module.getName()"+module.getName());
            if (!placedModules.contains(module.getName()))
                modulesToPlace_1.add(module.getName());
        }
        for(String m: modulesToPlace_1){
            System.out.println("in modulesToPlace_1, not placedModules: "+m);
        }
        /*
         * Filtering based on whether modules (to be placed) lower in physical topology are already placed
         */
        for (String moduleName : modulesToPlace_1) {
            boolean toBePlaced = true;

            for (AppEdge edge : app.getEdges()) {
                //CHECK IF OUTGOING DOWN EDGES ARE PLACED
                if (edge.getSource().equals(moduleName) && edge.getDirection() == Tuple.DOWN && !placedModules.contains(edge.getDestination()))
                    toBePlaced = false;
                //CHECK IF INCOMING UP EDGES ARE PLACED
                if (edge.getDestination().equals(moduleName) && edge.getDirection() == Tuple.UP && !placedModules.contains(edge.getSource()))
                    toBePlaced = false;
            }
            if (toBePlaced)
                modulesToPlace.add(moduleName);
        }

        return modulesToPlace;
    }


}
