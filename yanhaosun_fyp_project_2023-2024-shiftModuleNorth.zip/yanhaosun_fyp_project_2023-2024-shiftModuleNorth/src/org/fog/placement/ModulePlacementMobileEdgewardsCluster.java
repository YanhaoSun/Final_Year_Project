package org.fog.placement;

import java.sql.SQLOutput;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.apache.commons.math3.util.Pair;
import org.cloudbus.cloudsim.core.CloudSim;
import org.fog.application.AppEdge;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.application.selectivity.SelectivityModel;
import org.fog.entities.Actuator;
import org.fog.entities.FogDevice;
import org.fog.entities.Sensor;
import org.fog.entities.Tuple;
import org.fog.utils.Logger;

public class ModulePlacementMobileEdgewardsCluster extends ModulePlacement{

	protected ModuleMapping moduleMapping;
	protected List<Sensor> sensors;
	protected List<Actuator> actuators;
	protected Map<Integer, Double> currentCpuLoad;

	/**
	 * Stores the current mapping of application modules to fog devices
	 */
	protected Map<Integer, List<String>> currentModuleMap;
	protected Map<Integer, Map<String, Double>> currentModuleLoadMap;
	protected Map<Integer, Map<String, Integer>> currentModuleInstanceNum;


	public Map<AppEdge, Double> edgeRate = new HashMap<>();



	public ModulePlacementMobileEdgewardsCluster(List<FogDevice> fogDevices, List<Sensor> sensors, List<Actuator> actuators,
												 Application application, ModuleMapping moduleMapping, Boolean clusteringFeature){
		this.setFogDevices(fogDevices);
		this.setApplication(application);
		this.setModuleMapping(moduleMapping);
		this.setModuleToDeviceMap(new HashMap<String, List<Integer>>());
		this.setDeviceToModuleMap(new HashMap<Integer, List<AppModule>>());
		setClusteringFeature(clusteringFeature);
		setSensors(sensors);
		setActuators(actuators);
		setCurrentCpuLoad(new HashMap<Integer, Double>());
		setCurrentModuleMap(new HashMap<Integer, List<String>>());
		setCurrentModuleLoadMap(new HashMap<Integer, Map<String, Double>>());
		setCurrentModuleInstanceNum(new HashMap<Integer, Map<String, Integer>>());
		setModulesOnPath(new HashMap<Integer, Map<Integer,List<String>>>());
		for(FogDevice dev : getFogDevices()){
			getCurrentCpuLoad().put(dev.getId(), 0.0);
			getCurrentModuleLoadMap().put(dev.getId(), new HashMap<String, Double>());
			getCurrentModuleMap().put(dev.getId(), new ArrayList<String>());
			getCurrentModuleInstanceNum().put(dev.getId(), new HashMap<String, Integer>());
		}

		// place Modules In Path, create Module Instance On Device
		mapModules();
		//
		setModuleInstanceCountMap(getCurrentModuleInstanceNum());
		// getModulesOnPath stores deployed modules of current device
		mappedModules();
	}

	@Override
	protected void mapModules() {
		for(String deviceName : getModuleMapping().getModuleMapping().keySet()){
			for(String moduleName : getModuleMapping().getModuleMapping().get(deviceName)){
				int deviceId = CloudSim.getEntityId(deviceName);

				getCurrentModuleMap().get(deviceId).add(moduleName);
				getCurrentModuleLoadMap().get(deviceId).put(moduleName, 0.0);
				getCurrentModuleInstanceNum().get(deviceId).put(moduleName, 0);
			}
		}

		List<List<Integer>> leafToRootPaths = getLeafToRootPaths();
		System.out.println("\n****** placeModulesInPath ******");
		for(List<Integer> path : leafToRootPaths){
//			System.out.println("path = "+path.toString());
			placeModulesInPath(path);
		}
		for(int deviceId : getCurrentModuleMap().keySet()){
			for(String module : getCurrentModuleMap().get(deviceId)){
				if (getDeviceById(deviceId).getName().contains("gate")){
					int instanceNum = getCurrentModuleInstanceNum().get(deviceId).get(module);
					for(int num=1; num<=instanceNum; num++){
						createModuleInstanceOnDevice(getApplication().getModuleByName(module), getFogDeviceById(deviceId));
					}
				} else {
					createModuleInstanceOnDevice(getApplication().getModuleByName(module), getFogDeviceById(deviceId));
				}
			}
		}
	}


	private void mappedModules() {

		List<List<Integer>> leafToRootPaths = getLeafToRootPaths();
		setModulesOnDevice(currentModuleMap);

		for(List<Integer> path : leafToRootPaths){
			int leafNodeID = path.get(0);
			Map<Integer,List<String>> deviceWiseModules = new HashMap<Integer, List<String>>();
			for(int deviceID:path) {
				deviceWiseModules.put(deviceID,currentModuleMap.get(deviceID));
			}
			// getModulesOnPath stores deployed modules of current device
			getModulesOnPath().put(leafNodeID, deviceWiseModules);
		}
	}

	/**
	 * Get the list of modules that are ready to be placed
	 * @param placedModules Modules that have already been placed in current path
	 * @return list of modules ready to be placed
	 */
	private List<String> getModulesToPlace(List<String> placedModules){
		Application app = getApplication();
		List<String> modulesToPlace_1 = new ArrayList<String>();
		List<String> modulesToPlace = new ArrayList<String>();
		for(AppModule module : app.getModules()){
			if(!placedModules.contains(module.getName()))
				modulesToPlace_1.add(module.getName());
		}
		/*
		 * Filtering based on whether modules (to be placed) lower in physical topology are already placed
		 */
		for(String moduleName : modulesToPlace_1){
			boolean toBePlaced = true;

			for(AppEdge edge : app.getEdges()){
				//CHECK IF OUTGOING DOWN EDGES ARE PLACED
				if(edge.getSource().equals(moduleName) && edge.getDirection()==Tuple.DOWN && !placedModules.contains(edge.getDestination()))
					toBePlaced = false;
				//CHECK IF INCOMING UP EDGES ARE PLACED
				if(edge.getDestination().equals(moduleName) && edge.getDirection()==Tuple.UP && !placedModules.contains(edge.getSource()))
					toBePlaced = false;
			}
			if(toBePlaced)
				modulesToPlace.add(moduleName);
		}

		return modulesToPlace;
	}

	protected double getRateOfSensor(String sensorType){
		for(Sensor sensor : getSensors()){
			if(sensor.getTupleType().equals(sensorType))
				return 1/sensor.getTransmitDistribution().getMeanInterTransmitTime();
		}
		return 0;
	}


	private void placeModulesInPath(List<Integer> path) {
		if(path.size()==0)return;
		List<String> placedModules = new ArrayList<String>();
		Map<AppEdge, Double> appEdgeToRate = new HashMap<AppEdge, Double>();

		/**
		 * Periodic edges have a fixed periodicity of tuples, so setting the tuple rate beforehand
		 */
		for(AppEdge edge : getApplication().getEdges()){
			if(edge.isPeriodic()){
				appEdgeToRate.put(edge, 1/edge.getPeriodicity());
			}
		}

		for(Integer deviceId : path){
			FogDevice device = getFogDeviceById(deviceId);
			Map<String, Integer> sensorsAssociated = getAssociatedSensors(device);
			Map<String, Integer> actuatorsAssociated = getAssociatedActuators(device);
			placedModules.addAll(sensorsAssociated.keySet()); // ADDING ALL SENSORS TO PLACED LIST
			placedModules.addAll(actuatorsAssociated.keySet()); // ADDING ALL ACTUATORS TO PLACED LIST


			for(String sensor : sensorsAssociated.keySet()){
				for(AppEdge edge : getApplication().getEdges()){
					if(edge.getSource().equals(sensor)){
						appEdgeToRate.put(edge, sensorsAssociated.get(sensor)*getRateOfSensor(sensor));
					}
				}
			}
			/*
			 * Updating the AppEdge rates for the entire application based on knowledge so far
			 */

			boolean changed = true;
			while(changed){		//Loop runs as long as some new information is added
				changed=false;
				Map<AppEdge, Double> rateMap = new HashMap<AppEdge, Double>(appEdgeToRate);
				for(AppEdge edge : rateMap.keySet()){
					AppModule destModule = getApplication().getModuleByName(edge.getDestination());
					if(destModule == null)continue;
					Map<Pair<String, String>, SelectivityModel> map = destModule.getSelectivityMap();
					// clientModule three pairs:
					// pair{Sensor, RAW_DATA}
					// pair{Result1, Result1_Display}
					// pair{Result2, Result2_Display}
					// current edge is: {Source=Sensor, Destination=clientModule, tupleType=Sensor}
					for(Pair<String, String> pair : map.keySet()){
						if(pair.getFirst().equals(edge.getTupleType())){
							double outputRate = appEdgeToRate.get(edge)*map.get(pair).getMeanRate(); // getting mean rate from SelectivityModel
							AppEdge outputEdge = getApplication().getEdgeMap().get(pair.getSecond());
							if(!appEdgeToRate.containsKey(outputEdge) || appEdgeToRate.get(outputEdge)!=outputRate){
								// if some new information is available
								changed = true;
							}
							appEdgeToRate.put(outputEdge, outputRate);
						}
					}
				}
			}
			/*
			 * Getting the list of modules ready to be placed on current device on path
			 */
			// 找到需要被placed的modules, placedModules目前包含 sensors 和 actuators
			// 由于方法 getModulesToPlace 内部逻辑设计, 在这里执行这个方法的时候,
			// 每次只有一个moduleName被添加到 modulesToPlace 里面
			List<String> modulesToPlace = getModulesToPlace(placedModules);
			for (String mo: modulesToPlace){
				System.out.println("modulesToPlace: "+mo);
			}
			while(modulesToPlace.size() > 0){ // Loop runs until all modules in modulesToPlace are deployed in the path
				String moduleName = modulesToPlace.get(0);
				double totalCpuLoad = 0;

				//IF MODULE IS ALREADY PLACED UPSTREAM, THEN UPDATE THE EXISTING MODULE
				// 检查这个module是否在这条path上已经被部署了
				// 如果被部署了, 返回被部署的deviceId, 如果没有部署, 则返回-1
				int upsteamDeviceId = isPlacedUpstream(moduleName, path);
				if(upsteamDeviceId > 0){
					// 如果module被部署到了当前path上正在循环的这个device
					if(upsteamDeviceId==deviceId){
						placedModules.add(moduleName);
						// 该module已经被部署, 那么需要更新 modulesToPlace
						modulesToPlace = getModulesToPlace(placedModules);

						// NOW THE MODULE TO PLACE IS IN THE CURRENT DEVICE. CHECK IF THE NODE CAN SUSTAIN THE MODULE
						// 如果这个module是某个edge的dest, 那么需要更新totalCpuLength
						for(AppEdge edge : getApplication().getEdges()){		// take all incoming edges
							if(edge.getDestination().equals(moduleName)){
								double rate = appEdgeToRate.get(edge);
								//边缘设备上需要处理的数据量 = edge的速率(数据生成或产生的速率) 乘 边缘设备上处理一个数据单元或消息所需的时间
								totalCpuLoad += rate*edge.getTupleCpuLength();
							}
						}
						if(totalCpuLoad + getCurrentCpuLoad().get(deviceId) > device.getHost().getTotalMips()){
							Logger.debug("ModulePlacementEdgeward", "Need to shift module "+moduleName+" upstream from device " + device.getName());
							List<String> _placedOperators = shiftModuleNorth(moduleName, totalCpuLoad, deviceId, modulesToPlace);
							// 更新已部署的modules, 因为在shiftModulesNorth方法中可能会有新的module被shifted
							for(String placedOperator : _placedOperators){
								if(!placedModules.contains(placedOperator))
									placedModules.add(placedOperator);
							}
						} else{
//							System.out.println("come here");
							placedModules.add(moduleName);
							getCurrentCpuLoad().put(deviceId, getCurrentCpuLoad().get(deviceId)+totalCpuLoad);
							getCurrentModuleInstanceNum().get(deviceId).put(moduleName, getCurrentModuleInstanceNum().get(deviceId).get(moduleName)+1);
//							currentModuleMap.get(deviceId).add(moduleName);
							Logger.debug("ModulePlacementEdgeward", "AppModule "+moduleName+" can be created on device "+device.getName());
						}
					}
				}else{
					// FINDING OUT WHETHER PLACEMENT OF OPERATOR ON DEVICE IS POSSIBLE
					for(AppEdge edge : getApplication().getEdges()){		// take all incoming edges
						if(edge.getDestination().equals(moduleName)){
							double rate = appEdgeToRate.get(edge);
							//边缘设备上需要处理的数据量 = edge的速率(数据生成或产生的速率) 乘 边缘设备上处理一个数据单元或消息所需的时间
							totalCpuLoad += rate*edge.getTupleCpuLength();
						}
					}
					//getTotalMips 是 该设备的总MIPS(百万指令每秒，用于表示该设备的总计算能力)
					// totalCpuLoad是计算当前这个module所需要的 CPU load 之和, 比如有两个edges通过这个module,
					// 那么这个module就需要处理两个edges的数据量, 所以上面计算的是app的edge destination = moduleName时的所有CPULoad
					// 再比较看 (totalCpuLoad+目前设备已有的CPU load) 是否大于 当前device所能承载的极限, 看这个module是否能够部署在当前设备
//					System.out.println("totalCpuLoad = "+totalCpuLoad);
//					System.out.println("getCurrentCpuLoad().get(deviceId) = "+getCurrentCpuLoad().get(deviceId));
//					System.out.println("device.getHost().getTotalMips() = "+device.getHost().getTotalMips());
//					System.out.println("device = "+device.getName());
					if(totalCpuLoad + getCurrentCpuLoad().get(deviceId) > device.getHost().getTotalMips()){
						Logger.debug("ModulePlacementEdgeward", "Placement of operator "+moduleName+ "NOT POSSIBLE on device "+device.getName());
					}
					else{
						Logger.debug("ModulePlacementEdgeward", "Placement of operator "+moduleName+ " on device "+device.getName() + " successful.");
						getCurrentCpuLoad().put(deviceId, totalCpuLoad + getCurrentCpuLoad().get(deviceId));
						System.out.println("Placement of operator "+moduleName+ " on device "+device.getName() + " successful.");

						if(!currentModuleMap.containsKey(deviceId))
							currentModuleMap.put(deviceId, new ArrayList<String>());
						currentModuleMap.get(deviceId).add(moduleName);
						placedModules.add(moduleName);
						modulesToPlace = getModulesToPlace(placedModules);

						//getCurrentModuleLoadMap 存储 fog device(key) 以及 当前device上面所放置的 (module & module's total CPU load)(value)
						getCurrentModuleLoadMap().get(device.getId()).put(moduleName, totalCpuLoad);

						int max = 1;
						for(AppEdge edge : getApplication().getEdges()){
							if(edge.getSource().equals(moduleName) && actuatorsAssociated.containsKey(edge.getDestination()))
								max = Math.max(actuatorsAssociated.get(edge.getDestination()), max);
							if(edge.getDestination().equals(moduleName) && sensorsAssociated.containsKey(edge.getSource()))
								max = Math.max(sensorsAssociated.get(edge.getSource()), max);
						}
						getCurrentModuleInstanceNum().get(deviceId).put(moduleName, max);
					}
				}
				modulesToPlace.remove(moduleName);
			}
		}
		// 更新edgeRate, 因为只有当path中有mobile user的时候, appEdgeToRate才是非空的
		if(!appEdgeToRate.isEmpty()){
			setEdgeRate(appEdgeToRate);
			for(AppEdge edge : getApplication().getEdges()){
				if (getEdgeRate().isEmpty() || (!Objects.equals(appEdgeToRate.get(edge), getEdgeRate().get(edge)))){
					getEdgeRate().put(edge, appEdgeToRate.get(edge));
				}
			}
		}
	}

	/**
	 * Shifts a module moduleName from device deviceId northwards. This involves other modules that depend on it to be shifted north as well.
	 * @param moduleName
	 * @param cpuLoad cpuLoad of the module
	 * @param deviceId
	 */
	private List<String> shiftModuleNorth(String moduleName, double cpuLoad, Integer deviceId, List<String> operatorsToPlace) {
		System.out.println(CloudSim.getEntityName(deviceId)+" is shifting "+moduleName+" north.");
		List<String> modulesToShift = findModulesToShift(moduleName, deviceId);
//		for(String mod: modulesToShift){
//			System.out.println("modulesToShift = "+mod);
//		}
		Map<String, Integer> moduleToNumInstances = new HashMap<String, Integer>(); // Map of number of instances of modules that need to be shifted
		double totalCpuLoad = 0;
		Map<String, Double> loadMap = new HashMap<String, Double>();
		for(String module : modulesToShift){
			// loadMap存储当前module与当前module的load
			loadMap.put(module, getCurrentModuleLoadMap().get(deviceId).get(module));
//			System.out.println("getCurrentModuleLoadMap().get(deviceId).get(module) = "+getCurrentModuleLoadMap().get(deviceId).get(module));
//			System.out.println("getCurrentModuleInstanceNum().get("+getDeviceById(deviceId).getName()+").get("+module+") = "+getCurrentModuleInstanceNum().get(deviceId).get(module));
			// 第一次进来的时候 getCurrentModuleInstanceNum().get(mobile_0).get(client_MS) = 0
			moduleToNumInstances.put(module, getCurrentModuleInstanceNum().get(deviceId).get(module)+1);
			// 将当前device上的每一个将要被shifted的module的负载加起来
			totalCpuLoad += getCurrentModuleLoadMap().get(deviceId).get(module);
//			System.out.println("totalCpuLoad shift = "+totalCpuLoad);
			// 因为是将要被shifted的modules, 所以当前device相关的load, map, instance都要删除
			getCurrentModuleLoadMap().get(deviceId).remove(module);
			getCurrentModuleMap().get(deviceId).remove(module);
			getCurrentModuleInstanceNum().get(deviceId).remove(module);
		}
		// getCurrentCpuLoad存储的是当前device上已经占用的CPU load, 现在 modules shifted之后，就要把这些shifted modules所占用的load都移除掉
		getCurrentCpuLoad().put(deviceId, getCurrentCpuLoad().get(deviceId)-totalCpuLoad); // change info of current CPU load on device

		loadMap.put(moduleName, loadMap.get(moduleName)+cpuLoad);
		totalCpuLoad += cpuLoad;

		int id = getParentDevice(deviceId);
//		System.out.println("parentDevice of current device("+deviceId+") is "+id);
		while(true){ // Loop iterates over all devices in path upstream from current device. Tries to place modules (to be shifted northwards) on each of them.
			if(id==-1){
				// Loop has reached the apex fog device in hierarchy, and still could not place modules.
				Logger.debug("ModulePlacementEdgeward", "Could not place modules "+modulesToShift+" northwards.");
				break;
			}
			FogDevice fogDevice = getFogDeviceById(id);
			if(getCurrentCpuLoad().get(id) + totalCpuLoad > fogDevice.getHost().getTotalMips()){
				// Device cannot take up CPU load of incoming modules. Keep searching for device further north.
				List<String> _modulesToShift = findModulesToShift(modulesToShift, id);	// All modules in _modulesToShift are currently placed on device id
				double cpuLoadShifted = 0;		// the total CPU load shifted from device id to its parent
				for(String module : _modulesToShift){
					// 如果在parent device这里有新的要shift的module进来的话
					if(!modulesToShift.contains(module)){
						// Add information of all newly added modules (to be shifted)
						moduleToNumInstances.put(module, getCurrentModuleInstanceNum().get(id).get(module)+moduleToNumInstances.get(module));
						loadMap.put(module, getCurrentModuleLoadMap().get(id).get(module));
						cpuLoadShifted += getCurrentModuleLoadMap().get(id).get(module);
						totalCpuLoad += getCurrentModuleLoadMap().get(id).get(module);
						// Removing information of all modules (to be shifted north) in device with ID id
						getCurrentModuleLoadMap().get(id).remove(module);
						getCurrentModuleMap().get(id).remove(module);
						getCurrentModuleInstanceNum().get(id).remove(module);
					}
				}
				// 更新当前device上已被占用的CPU load(因为多了一个要转移的module, 所以要减去这个新的被转移的module的CPU load)
				getCurrentCpuLoad().put(id, getCurrentCpuLoad().get(id)-cpuLoadShifted); // CPU load on device id gets reduced due to modules shifting northwards

				modulesToShift = _modulesToShift;
				id = getParentDevice(id); // iterating to parent device
			} else{
				// Device (@ id) can accommodate modules. Placing them here.
				// 找到的这个parent device可以承担得起所有的modules, 那么就把所有的modules都放到这个devices上
				// 那么就需要更新load等等
				double totalLoad = 0;
				for(String module : loadMap.keySet()){
					totalLoad += loadMap.get(module);
					// 把每个module的load都放入当前device的load中
					getCurrentModuleLoadMap().get(id).put(module, loadMap.get(module));
					// 把每个module都放到当前device上
					getCurrentModuleMap().get(id).add(module);
					String module_ = module;
					int initialNumInstances = 0;
					if(getCurrentModuleInstanceNum().get(id).containsKey(module_))
						initialNumInstances = getCurrentModuleInstanceNum().get(id).get(module_);
					int finalNumInstances = initialNumInstances + moduleToNumInstances.get(module_);
					getCurrentModuleInstanceNum().get(id).put(module_, finalNumInstances);
				}
				// 更新目前parent device已占用的load
				getCurrentCpuLoad().put(id, totalLoad);
				operatorsToPlace.removeAll(loadMap.keySet());
				List<String> placedOperators = new ArrayList<String>();
				for(String op : loadMap.keySet())placedOperators.add(op);
				return placedOperators;
			}
		}
		return new ArrayList<String>();
	}

	/**
	 * Get all modules that need to be shifted northwards along with <b>module</b>.
	 * Typically, these other modules are those that are hosted on device with ID <b>deviceId</b> and lie upstream of <b>module</b> in application model.
	 * @param module the module that needs to be shifted northwards
	 * @param deviceId the fog device ID that it is currently on
	 * @return list of all modules that need to be shifted north along with <b>module</b>
	 */
	private List<String> findModulesToShift(String module, Integer deviceId) {
		List<String> modules = new ArrayList<String>();
		modules.add(module);
		return findModulesToShift(modules, deviceId);
	}
	/**
	 * Get all modules that need to be shifted northwards along with <b>modules</b>.
	 * Typically, these other modules are those that are hosted on device with ID <b>deviceId</b> and lie upstream of modules in <b>modules</b> in application model.
	 * @param module the module that needs to be shifted northwards
	 * @param deviceId the fog device ID that it is currently on
	 * @return list of all modules that need to be shifted north along with <b>modules</b>
	 */
	private List<String> findModulesToShift(List<String> modules, Integer deviceId) {
		List<String> upstreamModules = new ArrayList<String>();
		upstreamModules.addAll(modules);
		boolean changed = true;
		while(changed){ // Keep loop running as long as new information is added.
			changed = false;
			/*
			 * If there is an application edge UP from the module to be shifted to another module in the same device
			 */
			for(AppEdge edge : getApplication().getEdges()){
				// 这块是说如果一个edge的source和destination在同一个device上, 那么这个destination需要被shifted to north
				if(upstreamModules.contains(edge.getSource()) && edge.getDirection()==Tuple.UP &&
						getCurrentModuleMap().get(deviceId).contains(edge.getDestination())
						&& !upstreamModules.contains(edge.getDestination())){
					upstreamModules.add(edge.getDestination());
					changed = true;
				}
			}
		}
		return upstreamModules;
	}

	private int isPlacedUpstream(String operatorName, List<Integer> path) {
		for(int deviceId : path){
			if(currentModuleMap.containsKey(deviceId) && currentModuleMap.get(deviceId).contains(operatorName))
				return deviceId;
		}
		return -1;
	}

	/**
	 * Gets all sensors associated with fog-device <b>device</b>
	 * @param device
	 * @return map from sensor type to number of such sensors
	 */
	private Map<String, Integer> getAssociatedSensors(FogDevice device) {
		Map<String, Integer> endpoints = new HashMap<String, Integer>();
		for(Sensor sensor : getSensors()){
			if(sensor.getGatewayDeviceId()==device.getId()){
				if(!endpoints.containsKey(sensor.getTupleType()))
					endpoints.put(sensor.getTupleType(), 0);
				endpoints.put(sensor.getTupleType(), endpoints.get(sensor.getTupleType())+1);
			}
		}
		return endpoints;
	}

	/**
	 * Gets all actuators associated with fog-device <b>device</b>
	 * @param device
	 * @return map from actuator type to number of such sensors
	 */
	private Map<String, Integer> getAssociatedActuators(FogDevice device) {
		Map<String, Integer> endpoints = new HashMap<String, Integer>();
		for(Actuator actuator : getActuators()){
			if(actuator.getGatewayDeviceId()==device.getId()){
				if(!endpoints.containsKey(actuator.getActuatorType()))
					endpoints.put(actuator.getActuatorType(), 0);
				endpoints.put(actuator.getActuatorType(), endpoints.get(actuator.getActuatorType())+1);
			}
		}
		return endpoints;
	}

	@SuppressWarnings("serial")
	protected List<List<Integer>> getPaths(final int fogDeviceId){
		FogDevice device = (FogDevice)CloudSim.getEntity(fogDeviceId);
//		System.out.println("device.getName() = "+device.getName());
//		System.out.println("device.getId() = "+device.getId());
		if(device.getChildrenIds().size() == 0){
			final List<Integer> path =  (new ArrayList<Integer>(){{add(fogDeviceId);}});
			List<List<Integer>> paths = (new ArrayList<List<Integer>>(){{add(path);}});
			return paths;
		}
		List<List<Integer>> paths = new ArrayList<List<Integer>>();
		for(int childId : device.getChildrenIds()){
			List<List<Integer>> childPaths = getPaths(childId);
			for(List<Integer> childPath : childPaths)
				childPath.add(fogDeviceId);
			paths.addAll(childPaths);
		}
		return paths;
	}

	protected List<List<Integer>> getLeafToRootPaths(){
		FogDevice cloud=null;
		for(FogDevice device : getFogDevices()){
//			System.out.println("device name = "+device.getName());
//			System.out.println("id = "+device.getId());
			if(device.getName().equals("cloud"))
				cloud = device;
		}
//		System.out.println("cloud.getId() = "+cloud.getId());
		return getPaths(cloud.getId());
	}

	public ModuleMapping getModuleMapping() {
		return moduleMapping;
	}

	public void setModuleMapping(ModuleMapping moduleMapping) {
		this.moduleMapping = moduleMapping;
	}

	public Map<Integer, List<String>> getCurrentModuleMap() {
		return currentModuleMap;
	}

	public void setCurrentModuleMap(Map<Integer, List<String>> currentModuleMap) {
		this.currentModuleMap = currentModuleMap;
	}

	public List<Sensor> getSensors() {
		return sensors;
	}

	public void setSensors(List<Sensor> sensors) {
		this.sensors = sensors;
	}

	public List<Actuator> getActuators() {
		return actuators;
	}

	public void setActuators(List<Actuator> actuators) {
		this.actuators = actuators;
	}

	public Map<Integer, Double> getCurrentCpuLoad() {
		return currentCpuLoad;
	}

	public void setCurrentCpuLoad(Map<Integer, Double> currentCpuLoad) {
		this.currentCpuLoad= currentCpuLoad;
	}

	public Map<Integer, Map<String, Double>> getCurrentModuleLoadMap() {
		return currentModuleLoadMap;
	}

	public void setCurrentModuleLoadMap(
			Map<Integer, Map<String, Double>> currentModuleLoadMap) {
		this.currentModuleLoadMap = currentModuleLoadMap;
	}


	public Map<Integer, Map<String, Integer>> getCurrentModuleInstanceNum() {
		return currentModuleInstanceNum;
	}

	public Map<AppEdge, Double> getEdgeRate() {
		return edgeRate;
	}

	public void setEdgeRate(Map<AppEdge, Double> edgeRate) {
		this.edgeRate = edgeRate;
	}
	public void setCurrentModuleInstanceNum(
			Map<Integer, Map<String, Integer>> currentModuleInstanceNum) {
		this.currentModuleInstanceNum = currentModuleInstanceNum;
	}
}
