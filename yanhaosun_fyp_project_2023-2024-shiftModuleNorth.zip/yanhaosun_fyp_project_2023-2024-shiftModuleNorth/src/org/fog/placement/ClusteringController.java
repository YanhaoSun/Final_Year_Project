package org.fog.placement;

import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.SimEntity;
import org.cloudbus.cloudsim.core.SimEvent;
import org.fog.application.AppEdge;
import org.fog.application.AppModule;
import org.fog.application.Application;
import org.fog.entities.Actuator;
import org.fog.entities.FogDevice;
import org.fog.entities.Sensor;
import org.fog.mobilitydata.Location;
import org.fog.mobilitydata.References;
import org.fog.utils.*;
import org.json.simple.JSONObject;

import java.util.*;
import java.util.stream.Collectors;


public class ClusteringController extends SimEntity {

    public static boolean ONLY_CLOUD = false;

    private List<FogDevice> fogDevices;
    private List<Sensor> sensors;
    private List<Actuator> actuators;
    private LocationHandler locator;
    private Map<Integer, Integer> parentReference;


    private Map<String, Application> applications;



    public int algorithmType = References.DEFAULT_LOAD_BALANCE;

    private Map<String, Integer> appLaunchDelays;
    private List<Integer> clustering_levels;


    private Map<String, ModulePlacement> appModulePlacementPolicy;
    private Map<FogDevice, Double> moduleMigratingDelay = new HashMap<>();



    boolean dynamicClusteringSubmitted = false;
    private double distanceThreshold = 943;

    public ClusteringController(String name, List<FogDevice> fogDevices, List<Sensor> sensors, List<Actuator> actuators, LocationHandler locator) {
        super(name);
        this.applications = new HashMap<String, Application>();
        setLocator(locator);
        setAppLaunchDelays(new HashMap<String, Integer>());
        setParentReference(new HashMap<Integer, Integer>());
        setAppModulePlacementPolicy(new HashMap<String, ModulePlacement>());
        for (FogDevice fogDevice : fogDevices) {
            fogDevice.setControllerId(getId());
        }
        setFogDevices(fogDevices);
        setActuators(actuators);
        setSensors(sensors);
        connectWithLatencies();

    }

    public ClusteringController(String name, List<FogDevice> fogDevices, List<Sensor> sensors, List<Actuator> actuators, LocationHandler locator, List Levels) {
        super(name);
        this.applications = new HashMap<String, Application>();
        setLocator(locator);
        setAppLaunchDelays(new HashMap<String, Integer>());
        setParentReference(new HashMap<Integer, Integer>());
        setAppModulePlacementPolicy(new HashMap<String, ModulePlacement>());
        for (FogDevice fogDevice : fogDevices) {
//            System.out.println("getId() = "+getId());
            fogDevice.setControllerId(getId());
        }
        setFogDevices(fogDevices);
        setActuators(actuators);
        setSensors(sensors);
        // connect latencies between child and parent, and set parent for each child
        connectWithLatencies();
        this.clustering_levels = Levels;
    }

    private void setParentReference(HashMap<Integer, Integer> parentReference) {
        // TODO Auto-generated method stub
        this.parentReference = parentReference;
    }

    private FogDevice getFogDeviceById(int id) {
        for (FogDevice fogDevice : getFogDevices()) {
            if (id == fogDevice.getId())
                return fogDevice;
        }
        return null;
    }

    // set latencies between child and parent, and set parent for each child
    private void connectWithLatencies() {
//        for(Map.Entry<String, Integer> a: locator.getDataIdsLevelReferences().entrySet()){
//            System.out.println("getDataIdsLevelReferences.key = "+a.getKey());
//            System.out.println("getDataIdsLevelReferences.value = "+a.getValue());
//        }
//        for(Map.Entry<Integer, String> a: locator.getInstenceDataIdReferences().entrySet()){
//            // key(instanceID) 存储的是 deviceID
//            System.out.println("getInstenceDataIdReferences.key = "+a.getKey());
//            System.out.println("getInstenceDataIdReferences.value = "+a.getValue());
//        }
//        System.out.println("size of getInstenceDataIdReferences = "+locator.getInstenceDataIdReferences().size());
        // getDataIdsLevelReferences stores all fogDevices(key) with corresponding levels(values)
        for (String dataId : locator.getDataIdsLevelReferences().keySet()) {
            // getInstenceDataIdReferences stores all fogDevices, including one user,
            // one cloud, all proxy servers and gateWays and their mobile.getId()(key)
            for (int instenceId : locator.getInstenceDataIdReferences().keySet()) {
                if (locator.getInstenceDataIdReferences().get(instenceId).equals(dataId)) {
                    FogDevice fogDevice = getFogDeviceById(instenceId);

                    // set parent id for each of fogDevice
                    if (locator.getDataIdsLevelReferences().get(dataId) == locator.getLevelID("User") && fogDevice.getParentId() == References.NOT_SET) {
                        int parentID = locator.determineParent(fogDevice.getId(), References.INIT_TIME);
                        // parentReference 存储: key, deviceID      value, parentDeviceID
                        parentReference.put(fogDevice.getId(), parentID);
                        fogDevice.setParentId(parentID);
                    } else
                        parentReference.put(fogDevice.getId(), fogDevice.getParentId());
                }
            }
        }


        FogDevice cloud = getCloud();
        parentReference.put(cloud.getId(), cloud.getParentId());
        for (FogDevice fogDevice : getFogDevices()) {
            FogDevice parent = getFogDeviceById(parentReference.get(fogDevice.getId()));
            if (parent == null)
                continue;
            double latency = fogDevice.getUplinkLatency();
//            System.out.println("latencylatencylatency = "+latency);
//            System.out.println("device = "+fogDevice.getName());
//            System.out.println("getULLC = "+latency);
//            System.out.println("parent = "+parent.getName());
            // set latency between parent and its child
            parent.getChildToLatencyMap().put(fogDevice.getId(), latency);
            parent.getChildrenIds().add(fogDevice.getId());
//            for(Map.Entry a: parent.getChildToLatencyMap().entrySet()){
//                System.out.println("child id = "+a.getKey());
//                System.out.println("child latency = "+a.getValue());
//            }
            if(parent.getChildrenIds().isEmpty()){
                System.out.println("the empty parent = "+parent.getName());
            }
            System.out.println("Child " + fogDevice.getName() + "("+fogDevice.getId()+")"+"\t----->\tParent " + parent.getName());
        }
    }

    @Override
    public void startEntity() {
//        System.out.println("adskjgbdskhbgs");
        // 开始组成clustering, 所有 gateWay server 和 clustering 的 level 是相同的
//        System.out.println("clustering_levels = "+clustering_levels);
        switch (algorithmType){
            case 1:
                System.out.println("No load balance, start clustering now");
                clusteringSubmit(clustering_levels);
                break;
            default:
                break;
        }
        for (String appId : applications.keySet()) {
//            System.out.println("getAppLaunchDelays().get(appId) = "+getAppLaunchDelays().get(appId));
            if (getAppLaunchDelays().get(appId) == 0)
                //将 application 提交到当前application需要使用的devices上,
                //同时，将application的modules的部署情况也发送到相对应的devices上
                processAppSubmit(applications.get(appId));
            else
                send(getId(), getAppLaunchDelays().get(appId), FogEvents.APP_SUBMIT, applications.get(appId));
        }

        send(getId(), Config.RESOURCE_MANAGE_INTERVAL, FogEvents.CONTROLLER_RESOURCE_MANAGE);

        send(getId(), Config.MAX_SIMULATION_TIME, FogEvents.STOP_SIMULATION);

        sendNow(getId(), FogEvents.MOBILITY_SUBMIT);

        for (FogDevice dev : getFogDevices())
            sendNow(dev.getId(), FogEvents.RESOURCE_MGMT);
    }

    @Override
    public void processEvent(SimEvent ev) {
//        System.out.println("|||||||ClusteringController tag = "+ev.getTag());
        switch (ev.getTag()) {
            case FogEvents.APP_SUBMIT:
                processAppSubmit(ev);
                break;
            case FogEvents.MOBILITY_SUBMIT:
                switch (algorithmType){
                    case 1:
                        processMobilityData();
                        break;
                    case 2:
                        processMobilityDataAlter();
                        break;
                    default:
                        System.out.println("Neither default nor alternative algorithm is executed.");
                }
                break;
            case FogEvents.MOBILITY_MANAGEMENT:
                switch (algorithmType){
                    case 1:
                        processMobility(ev);
                        break;
                    case 2:
//                        if(!dynamicClusteringSubmitted){
//                        } else {
                        processMobilityLoadBalance(ev);
//                        }
                        break;
                    default:
                        System.out.println("Neither default nor alternative algorithm is executed.");
                }
                break;
            case FogEvents.TUPLE_FINISHED:
                processTupleFinished(ev);
                break;
            case FogEvents.CONTROLLER_RESOURCE_MANAGE:
                manageResources();
                break;
            case FogEvents.STOP_SIMULATION:
                CloudSim.stopSimulation();
                printTimeDetails();
                printPowerDetails();
                printCostDetails();
                printNetworkUsageDetails();
                printMigrationDelayDetails();
                System.exit(0);
                break;

        }
    }
    public void dynamicClusteringSubmit(List Levels, FogDevice fogDevice,Double timeEntry) {
        // TODO Auto-generated method stub
//        System.out.println("测试1");
//        FogDevice fogDevice = (FogDevice) ev.getData();
//        FogDevice prevParent = getFogDeviceById(parentReference.get(fogDevice.getId()));
        // 不断在根据 userLocation-melbCBD_1.csv中的位置计算新的parent(通过方法 determineParent())
        FogDevice clusterHeader = getFogDeviceById(locator.determineClusterHeader(fogDevice, fogDevice.getId(), timeEntry));
        if(clusterHeader != null)
            fogDevice.setClusterHeader(clusterHeader);
//        System.out.println("old parent of "+fogDevice.getName()+" = "+prevParent.getName());
        System.out.println("cluster header of "+fogDevice.getName()+" = "+clusterHeader.getName());


        System.out.println(CloudSim.clock() + " Start sending Clustering Request to Fog Devices in level: " + Levels);
        for (int i = 0; i < Levels.size(); i++) {
            int clusterLevel = (int) Levels.get(i);
            for (FogDevice fogDev : fogDevices) {
                if (fogDev.getName().equals(clusterHeader.getName())){
                    fogDev.setClusterHeader(true);
                }
//                System.out.println(CloudSim.clock() + " fog Device: " + fogDev.getName() + " with id: " + fogDev.getId() + " is at level: " + fogDev.getLevel());
                if ((int) fogDev.getLevel() == clusterLevel && fogDev.isClusterHeader()) {
                    JSONObject jsonMessage = new JSONObject();
                    jsonMessage.put("locationsInfo", getLocator());
                    sendNow(fogDev.getId(), FogEvents.START_DYNAMIC_CLUSTERING, jsonMessage);
                    fogDev.setClusterHeader(false);
                }
            }
        }

        dynamicClusteringSubmitted = true;

    }
    public void clusteringSubmit(List Levels) {
//        System.out.println("sjhfoiahfoadf");
        System.out.println(CloudSim.clock() + " Start sending Clustering Request to Fog Devices in level: " + Levels);
        for (int i = 0; i < Levels.size(); i++) {
            int clusterLevel = (int) Levels.get(i);
            for (FogDevice fogDevice : fogDevices) {
                System.out.println(CloudSim.clock() + " fog Device: " + fogDevice.getName() + " with id: " + fogDevice.getId() + " is at level: " + fogDevice.getLevel());
                if ((int) fogDevice.getLevel() == clusterLevel) {
                    JSONObject jsonMessage = new JSONObject();
                    jsonMessage.put("locationsInfo", getLocator());
                    sendNow(fogDevice.getId(), FogEvents.START_DYNAMIC_CLUSTERING, jsonMessage);
                }
            }
        }

    }


    private void printMigrationDelayDetails() {
        // TODO Auto-generated method stub
        System.out.println("Total time required for module migration = " + MigrationDelayMonitor.getMigrationDelay());
    }

    /*private void printFogDeviceChildren(int deviceID) {
        // TODO Auto-generated method stub
        System.out.println("Childs of "+getFogDeviceById(deviceID).getName());
        for(Integer childId:getFogDeviceById(deviceID).getChildrenIds())
            System.out.println(getFogDeviceById(childId).getName()+"("+childId+")");

    }*/
    private double calculateModulesTotalCpuLoad(ModulePlacementMobileEdgewardsCluster modulePlacementMobileEdgewardsCluster, List<String> preParentMigratingModules, Application application){
        double totalCpuLoad = 0.0;
        for (String moduleName: preParentMigratingModules) {
            for(AppEdge edge : application.getEdges()){		// take all incoming edges
                if(edge.getDestination().equals(moduleName)){
                    double rate = modulePlacementMobileEdgewardsCluster.getEdgeRate().get(edge);
                    //边缘设备上需要处理的数据量 = edge的速率(数据生成或产生的速率) 乘 边缘设备上处理一个数据单元或消息所需的时间
                    totalCpuLoad += rate*edge.getTupleCpuLength();
                }
            }
        }
        return totalCpuLoad;
    }
    private void processMobilityLoadBalance(SimEvent ev) {
        // TODO Auto-generated method stub
        double clusterHeaderResponseTime = 0.0;
        double dynamicClusteringTime = 0.0;
        double loadBalanceTime = 0.0;
        double migratingTime = 0.0;

        FogDevice newParent = null;
        FogDevice fogDevice = (FogDevice) ev.getData();
        FogDevice prevParent = getFogDeviceById(parentReference.get(fogDevice.getId()));
        FogDevice clusterHeader = getFogDeviceById(locator.determineClusterHeader(fogDevice, fogDevice.getId(), CloudSim.clock()));
        System.out.println("\nclusterHeader of "+fogDevice.getName()+" = "+clusterHeader.getName()+"\n");
        clusterHeader.setClusterHeader(true);
        if(clusterHeader != null) {
            fogDevice.setClusterHeader(clusterHeader);
        }
        System.out.println(CloudSim.clock() + " Starting Dynamic Clustering for " + fogDevice.getName());
        clusterHeader.processDynamicClustering(getLocator());

        String applicationNameTemp = fogDevice.getActiveApplications().get(0);
        List<String> preParentMigratingModules = new ArrayList<String>();
        preParentMigratingModules = getAppModulePlacementPolicy().get(applicationNameTemp).getModulesOnPath().get(fogDevice.getId()).get(prevParent.getId());
        ModulePlacementMobileEdgewardsCluster modulePlacementMobileEdgewardsCluster = (ModulePlacementMobileEdgewardsCluster)getAppModulePlacementPolicy().get(applicationNameTemp);
        Application app = getApplications().get(applicationNameTemp);
        double modulesTotalCpuLoad = 0.0;
        modulesTotalCpuLoad = calculateModulesTotalCpuLoad(modulePlacementMobileEdgewardsCluster, preParentMigratingModules, getApplications().get(applicationNameTemp));
        Map<FogDevice, Double> candidateNewParentDevices = locator.determineCandidateParentsWithLoadBalance(modulePlacementMobileEdgewardsCluster, app, prevParent, fogDevice, fogDevice.getId(), clusterHeader, preParentMigratingModules, modulesTotalCpuLoad);
        clusterHeaderResponseTime = locator.getClusterHeaderResponseTime();
        System.out.println("clusterHeaderResponseTime = "+clusterHeaderResponseTime);
        dynamicClusteringTime = clusterHeader.getDynamicClusteringTime();
        System.out.println("dynamicClusteringTime = "+dynamicClusteringTime);
        loadBalanceTime = locator.getLoadBalanceTime();
        System.out.println("loadBalanceTime = "+loadBalanceTime);
        migratingTime = clusterHeaderResponseTime + dynamicClusteringTime + loadBalanceTime;
        System.out.println("initial migratingTime = "+migratingTime);
        double minDelay = 10000.0;
        double minLatency = 100.0;
        Map<FogDevice, List<Double>> deviceUpDownDelayMap = new HashMap<>();
        if (!candidateNewParentDevices.isEmpty()){
            ArrayList<FogDevice> candidateParentList = new ArrayList<>();
            for (Map.Entry<FogDevice, Double> candidateNewParentDeviceMap: candidateNewParentDevices.entrySet()){
                double candidateLatency = candidateNewParentDeviceMap.getValue();
                double upDelay = 0.0;
                double downDelay = 0.0;
                List<Integer> candidateNewParentPath = getPathsToCloud(candidateNewParentDeviceMap.getKey().getId());
                List<Integer> prevParentPath = getPathsToCloud(prevParent.getId());
                int commonAncestor = determineAncestor(candidateNewParentPath, prevParentPath);
                List<Double> upDownDelay = new ArrayList<>();
                for (String moduleName : preParentMigratingModules) {
                    upDelay += getUpDelay(prevParent.getId(), commonAncestor, getApplications().get(applicationNameTemp).getModuleByName(moduleName));
                    upDelay += locator.calculateDelayFactor(prevParent.getId(), commonAncestor, CloudSim.clock());
                    downDelay += getDownDelay(candidateNewParentDeviceMap.getKey().getId(), commonAncestor, getApplications().get(applicationNameTemp).getModuleByName(moduleName));
                    downDelay += locator.calculateDelayFactor(candidateNewParentDeviceMap.getKey().getId(), commonAncestor, CloudSim.clock());
                }
                System.out.println("============== From preParent <"+prevParent.getName()+"> to candidateParent <"+candidateNewParentDeviceMap.getKey().getName()+"> ==================");
                System.out.println("============== Latency of "+candidateNewParentDeviceMap.getKey().getName()+" is "+candidateLatency);
                if (candidateLatency<minLatency){
                    minLatency = candidateLatency;
                    candidateParentList.clear();
                    candidateParentList.add(candidateNewParentDeviceMap.getKey());
                } else if (candidateLatency==minLatency){
                    candidateParentList.add(candidateNewParentDeviceMap.getKey());
                }

                upDownDelay.add(upDelay);
                upDownDelay.add(downDelay);
                deviceUpDownDelayMap.put(candidateNewParentDeviceMap.getKey(), upDownDelay);
            }
            // if there are more than one node with same latency, then we select the one with the least delay as new parent
            if (candidateParentList.size()>1){
                double totalDelay = 0;
                System.out.println("\n============== There are more than one node with same latency, select the one with the least delay ==============");
                for (FogDevice candidateDevice: candidateParentList){
                    totalDelay = deviceUpDownDelayMap.get(candidateDevice).get(0)+deviceUpDownDelayMap.get(candidateDevice).get(1);
                    System.out.println("****** For candidate device "+candidateDevice.getName()+" ******");
                    System.out.println("****** upDelay = "+deviceUpDownDelayMap.get(candidateDevice).get(0)+" ******");
                    System.out.println("****** downDelay = "+deviceUpDownDelayMap.get(candidateDevice).get(1)+" ******");
                    System.out.println("****** Total delay is "+totalDelay+" ******\n");
                    if (totalDelay<=minDelay){
                        minDelay = totalDelay;
                        newParent = candidateDevice;
                    }
                }
                migratingTime += totalDelay;
            } else {
                // if there are only one node with the least latency, then we select this node as new parent
                newParent = candidateParentList.get(0);
                migratingTime += (deviceUpDownDelayMap.get(newParent).get(0)+deviceUpDownDelayMap.get(newParent).get(1));
                System.out.println("after add upDelay and downDelay, migratingTIme = "+migratingTime);
            }
        }
        if (prevParent.getId() != newParent.getId()) {
            System.out.println("\n============== There is only one node with the least latency, then we select this node as new parent ==============");
            parentReference.put(fogDevice.getId(), newParent.getId());
            fogDevice.setParentId(newParent.getId());
            System.out.println("New parent is "+newParent.getName());
            System.out.println("Child " + fogDevice.getName() +": preParent "+prevParent.getName()+"\t----->\tParent " + newParent.getName());
            newParent.getChildToLatencyMap().put(fogDevice.getId(), fogDevice.getUplinkLatency());
            newParent.addChild(fogDevice.getId());
            prevParent.removeChild(fogDevice.getId());
            getAppModulePlacementPolicy().get(applicationNameTemp).getModulesOnPath().get(fogDevice.getId()).remove(prevParent.getId());
            getAppModulePlacementPolicy().get(applicationNameTemp).getModulesOnPath().get(fogDevice.getId()).put(newParent.getId(), preParentMigratingModules);
            double upDelay = 0.0;
            double downDelay = 0.0;
            for (String moduleName : preParentMigratingModules) {
                upDelay = deviceUpDownDelayMap.get(newParent).get(0);
                downDelay = deviceUpDownDelayMap.get(newParent).get(1);
                double singleModuleCpuLoad = 0.0;
                for(AppEdge edge : app.getEdges()){		// take all incoming edges
                    if(edge.getDestination().equals(moduleName)){
                        double rate = modulePlacementMobileEdgewardsCluster.getEdgeRate().get(edge);
                        singleModuleCpuLoad += rate*edge.getTupleCpuLength();
                    }
                }
                // update newParent
                int instanceNum = 0;
                if (modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(newParent.getId()).isEmpty()){
                    modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(newParent.getId()).put(moduleName, 1);
                } else {
                    instanceNum = modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(newParent.getId()).get(moduleName);
                    modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(newParent.getId()).put(moduleName, instanceNum+1);
                }

                modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().put(newParent.getId(), modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(newParent.getId())+modulesTotalCpuLoad);
                modulePlacementMobileEdgewardsCluster.getCurrentModuleLoadMap().get(newParent.getId()).put(moduleName, singleModuleCpuLoad);

                // update preParent
                modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(prevParent.getId()).put(moduleName, modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(prevParent.getId()).get(moduleName)-1);
                modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().put(prevParent.getId(), modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(prevParent.getId())-modulesTotalCpuLoad);
                modulePlacementMobileEdgewardsCluster.getCurrentModuleLoadMap().get(prevParent.getId()).remove(moduleName);

                moduleMigratingDelay.put(fogDevice, migratingTime);
                JSONObject jsonSend = new JSONObject();
                jsonSend.put("module", getApplications().get(applicationNameTemp).getModuleByName(moduleName));
                jsonSend.put("delay", moduleMigratingDelay.get(fogDevice));

                JSONObject jsonReceive = new JSONObject();
                jsonReceive.put("module", getApplications().get(applicationNameTemp).getModuleByName(moduleName));
                jsonReceive.put("delay", 0.0);
                jsonReceive.put("application", getApplications().get(applicationNameTemp));

                send(prevParent.getId(), upDelay, FogEvents.MODULE_SEND, jsonSend);
                send(newParent.getId(), downDelay, FogEvents.MODULE_RECEIVE, jsonReceive);

                System.out.println("Migrating " + moduleName + " from " + prevParent.getName() + " to " + newParent.getName());
            }
        } else {
            prevParent.getHost().getRamProvisioner().setAvailableRam(prevParent.getHost().getRamProvisioner().getAvailableRam()+512);
            prevParent.getHost().getBwProvisioner().setAvailableBw(prevParent.getHost().getBwProvisioner().getAvailableBw()+1000);
            moduleMigratingDelay.put(fogDevice, clusterHeaderResponseTime + dynamicClusteringTime + loadBalanceTime);
            System.out.println("\n============== The previous parent can provide the least latency, so "+fogDevice.getName()+" does not move ==============");
            System.out.println("Child " + fogDevice.getName() +": preParent "+prevParent.getName()+"\t----->\tParent " + newParent.getName());
        }
        clusterHeader.setClusterHeader(false);
        int clusterHeaderId = clusterHeader.getId();
        List<Integer> clusterMemberList = new ArrayList<>();
        Map<FogDevice, Map<String, Object>> clusterMemberResourceInformation = new HashMap<>();

        ((FogDevice) CloudSim.getEntity(clusterHeaderId)).setIsInCluster(false);
        ((FogDevice) CloudSim.getEntity(clusterHeaderId)).setSelfCluster(false);
        ((FogDevice) CloudSim.getEntity(clusterHeaderId)).setClusterMembers(clusterMemberList);
        Map<Integer, Double> latencyMapL2 = new HashMap<>();
        ((FogDevice) CloudSim.getEntity(clusterHeaderId)).setClusterMembersToLatencyMap(latencyMapL2);
        ((FogDevice) CloudSim.getEntity(clusterHeaderId)).setClusterMemberResourceInformation(clusterMemberResourceInformation);
    }
    private void printDeviceResources(FogDevice newParent, ModulePlacementMobileEdgewardsCluster modulePlacementMobileEdgewardsCluster){
        long candidateSize = newParent.getHost().getStorage();
        int candidateRam = newParent.getHost().getRamProvisioner().getAvailableRam();
        long candidateBw = newParent.getHost().getBwProvisioner().getAvailableBw();
//        double candidateMips = newParent.getHost().getVmScheduler().getAvailableMips();

        double candidateCpuLoad = newParent.getHost().getTotalMips() - modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(newParent.getId());
        System.out.println("============== candidate parent device <"+newParent.getName()+"> from cluster ==================");
        System.out.println("candidateCpuLoad of candidate = "+candidateCpuLoad);
        System.out.println("candidateSize of candidate = "+candidateSize);
        System.out.println("candidateRam of modules = "+candidateRam);
        System.out.println("candidateBw of modules = "+candidateBw);
//        System.out.println("candidateMips of modules = "+candidateMips);
        System.out.println("==================================================================================\n");
    }
    private void printModuleResources(Double modulesTotalCpuLoad, String applicationName, String moduleName){
        Application app = getApplications().get(applicationName);
        AppModule tempModule = app.getModuleByName(moduleName);
        long totalModuleSize = tempModule.getSize();
        int totalModuleRam = tempModule.getRam();
        long totalModuleBw = tempModule.getBw();
        double totalModuleMips = tempModule.getMips();
//        double modulesTotalCpuLoad = 0.0;

//        ArrayList<String> list = new ArrayList<>(Collections.singletonList(moduleName));
//        modulesTotalCpuLoad = calculateModulesTotalCpuLoad(modulePlacementMobileEdgewardsCluster, list, app);

        System.out.println("============== resources needed by module <"+moduleName+"> ==================");

        System.out.println("totalCpuLoad of modules = "+modulesTotalCpuLoad);
        System.out.println("totalModuleSize of modules = "+totalModuleSize);
        System.out.println("totalModuleRam of modules = "+totalModuleRam);
        System.out.println("totalModuleBw of modules = "+totalModuleBw);
//        System.out.println("totalModuleMips of modules = "+totalModuleMips);
        System.out.println("=============================================================================\n");
    }
    @SuppressWarnings("unchecked")
    private void processMobility(SimEvent ev) {
        // TODO Auto-generated method stub
//        System.out.println("测试1");
        double newParentResponseTime = 0.0;
        double migratingTime = 0.0;

        FogDevice fogDevice = (FogDevice) ev.getData();
        FogDevice prevParent = getFogDeviceById(parentReference.get(fogDevice.getId()));
        // 不断在根据 userLocation-melbCBD_1.csv中的位置计算新的parent(通过方法 determineParent())
        FogDevice newParent = getFogDeviceById(locator.determineParent(fogDevice.getId(), CloudSim.clock()));
        System.out.println("old parent of "+fogDevice.getName()+" = "+prevParent.getName());
        System.out.println("new parent of "+fogDevice.getName()+" = "+newParent.getName());
        System.out.println(CloudSim.clock() + " Starting Mobility Management for " + fogDevice.getName()+"\n");
        parentReference.put(fogDevice.getId(), newParent.getId());
        List<String> migratingModules = new ArrayList<String>();
        newParentResponseTime = locator.getNewParentResponseTime();
//        System.out.println("newParentResponseTime = "+newParentResponseTime);
        // TODO: 考虑要不要在这里加一个resource check, 因为没有负载均衡的时候就算newParent is full, 但是还是会进行send
        if (prevParent.getId() != newParent.getId()) {
            //printFogDeviceChildren(newParent.getId());
            //printFogDeviceChildren(prevParent.getId());

            //common ancestor policy
            List<Integer> newParentPath = getPathsToCloud(newParent.getId());
            List<Integer> prevParentPath = getPathsToCloud(prevParent.getId());
            int commonAncestor = determineAncestor(newParentPath, prevParentPath);


            fogDevice.setParentId(newParent.getId());
            System.out.println("Child " + fogDevice.getName() + "\t----->\tParent " + newParent.getName());

            newParent.getChildToLatencyMap().put(fogDevice.getId(), fogDevice.getUplinkLatency());
            newParent.addChild(fogDevice.getId());
            prevParent.removeChild(fogDevice.getId());
            for (String applicationName : fogDevice.getActiveApplications()) {
                ModulePlacementMobileEdgewardsCluster modulePlacementMobileEdgewardsCluster = (ModulePlacementMobileEdgewardsCluster)getAppModulePlacementPolicy().get(applicationName);
                printDeviceResources(newParent, modulePlacementMobileEdgewardsCluster);
                migratingModules = getAppModulePlacementPolicy().get(applicationName).getModulesOnPath().get(fogDevice.getId()).get(prevParent.getId());
                getAppModulePlacementPolicy().get(applicationName).getModulesOnPath().get(fogDevice.getId()).remove(prevParent.getId());
                getAppModulePlacementPolicy().get(applicationName).getModulesOnPath().get(fogDevice.getId()).put(newParent.getId(), migratingModules);
                Application app = getApplications().get(applicationName);
                double modulesTotalCpuLoad = 0.0;
                for (String moduleName : migratingModules) {
                    double upDelay;
                    double downDelay;
                    upDelay = getUpDelay(prevParent.getId(), commonAncestor, getApplications().get(applicationName).getModuleByName(moduleName));
                    upDelay += locator.calculateDelayFactor(prevParent.getId(), commonAncestor, CloudSim.clock());

                    downDelay = getDownDelay(newParent.getId(), commonAncestor, getApplications().get(applicationName).getModuleByName(moduleName));
                    downDelay += locator.calculateDelayFactor(newParent.getId(), commonAncestor, CloudSim.clock());

                    AppModule tempModule = app.getModuleByName(moduleName);
                    ArrayList<String> list = new ArrayList<>(Collections.singletonList(moduleName));
                    modulesTotalCpuLoad = calculateModulesTotalCpuLoad(modulePlacementMobileEdgewardsCluster, list, app);
                    printModuleResources(modulesTotalCpuLoad, applicationName, moduleName);


                    modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().put(newParent.getId(), modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(newParent.getId())+modulesTotalCpuLoad);
//                    modulePlacementMobileEdgewardsCluster.currentModuleMap.get(newParent.getId()).add(moduleName);
//                    modulePlacementMobileEdgewardsCluster.getCurrentModuleLoadMap().get(newParent.getId()).put(moduleName, singleModuleCpuLoad);

                    // 更新preParent
                    modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(prevParent.getId()).put(moduleName, modulePlacementMobileEdgewardsCluster.getCurrentModuleInstanceNum().get(prevParent.getId()).get(moduleName)-1);
                    modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().put(prevParent.getId(), modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(prevParent.getId())-modulesTotalCpuLoad);
//                    modulePlacementMobileEdgewardsCluster.currentModuleMap.get(prevParent.getId()).remove(moduleName);
//                    modulePlacementMobileEdgewardsCluster.getCurrentModuleLoadMap().get(prevParent.getId()).remove(moduleName);
                    prevParent.getChildToLatencyMap().remove(fogDevice.getId());
                    newParent.getChildToLatencyMap().put(fogDevice.getId(), fogDevice.getUplinkLatency());
                    moduleMigratingDelay.put(fogDevice, (upDelay+downDelay+newParentResponseTime));
                    System.out.println("============== From preParent <"+prevParent.getName()+"> to newParent <"+newParent.getName()+"> ==================");
//                    System.out.println("============== upDelay = "+upDelay);
//                    System.out.println("============== downDelay = "+downDelay);
                    System.out.println("============== Migration time is "+moduleMigratingDelay.get(fogDevice)+"\n");

                    JSONObject jsonSend = new JSONObject();
                    jsonSend.put("module", getApplications().get(applicationName).getModuleByName(moduleName));
                    jsonSend.put("delay", moduleMigratingDelay.get(fogDevice));

                    JSONObject jsonReceive = new JSONObject();
                    jsonReceive.put("module", getApplications().get(applicationName).getModuleByName(moduleName));
                    jsonReceive.put("delay", 0.0);
                    jsonReceive.put("application", getApplications().get(applicationName));

                    send(prevParent.getId(), upDelay, FogEvents.MODULE_SEND, jsonSend);
                    send(newParent.getId(), downDelay, FogEvents.MODULE_RECEIVE, jsonReceive);

                    //TODO: 当user进行移动以后, 可以发送FogEvents.START_DYNAMIC_CLUSTERING, 进行动态集群
//                    JSONObject jsonMessage = new JSONObject();
//                    jsonMessage.put("locationsInfo", getLocator());
//                    sendNow(fogDevice.getId(), FogEvents.START_DYNAMIC_CLUSTERING, jsonMessage);



                    System.out.println("Migrating " + moduleName + " from " + prevParent.getName() + " to " + newParent.getName());
                }
            }

            // = get
            //printFogDeviceChildren(newParent.getId());
            //printFogDeviceChildren(prevParent.getId());
//            FogDevice deviceNN = getFogDeviceById(3);
//            System.out.println("device测试 完成接收 = "+deviceNN.getName());
//            System.out.println("device ram = "+deviceNN.getHost().getRamProvisioner().getAvailableRam());
//            System.out.println("device bw = "+deviceNN.getHost().getBwProvisioner().getAvailableBw());
//            System.out.println("device mips = "+deviceNN.getHost().getVmScheduler().getAvailableMips());
        } else {
            moduleMigratingDelay.put(fogDevice, newParentResponseTime);
        }


    }

    private double getDownDelay(int deviceID, int commonAncestorID, AppModule module) {
        // TODO Auto-generated method stub
        double networkDelay = 0.0;
        while (deviceID != commonAncestorID) {
            networkDelay = networkDelay + module.getSize() / getFogDeviceById(deviceID).getDownlinkBandwidth();
            deviceID = getFogDeviceById(deviceID).getParentId();
        }
        return networkDelay;
    }


    private double getUpDelay(int deviceID, int commonAncestorID, AppModule module) {
        // TODO Auto-generated method stub
        double networkDelay = 0.0;
        while (deviceID != commonAncestorID) {
            networkDelay = networkDelay + module.getSize() / getFogDeviceById(deviceID).getUplinkBandwidth();
            deviceID = getFogDeviceById(deviceID).getParentId();
        }
        return networkDelay;
    }

    private int determineAncestor(List<Integer> newParentPath, List<Integer> prevParentPath) {
        // TODO Auto-generated method stub
        List<Integer> common = newParentPath.stream().filter(prevParentPath::contains).collect(Collectors.toList());
        return common.get(0);
    }

    private List<Integer> getPathsToCloud(int deviceID) {
        // TODO Auto-generated method stub
        List<Integer> path = new ArrayList<Integer>();
        while (!locator.isCloud(deviceID)) {
            path.add(deviceID);
            deviceID = getFogDeviceById(deviceID).getParentId();
        }
        path.add(getCloud().getId());
        return path;
    }
    private void processMobilityDataAlter() {
        // TODO Auto-generated method stub
//        System.out.println("在processMobilityDataAlter");
        List<Double> timeSheet = new ArrayList<Double>();
        for (FogDevice fogDevice : getFogDevices()) {
            if (locator.isAMobileDevice(fogDevice.getId())) {
                // timeSheet记录的是user在每个location的时间(event time)
                // 也就是移动前那个位置的时间和移动后那个位置的时间
                String dataId = locator.getDataIdByInstanceID(fogDevice.getId());
                timeSheet = locator.getTimeSheet(fogDevice.getId());

                Double initialTime = timeSheet.get(0);
                // 需要进行比较前后两次位置是否发生变化, 如果不变, 则不能进行MOBILITY_MANAGEMENT
                // 如果变了, 则可以MOBILITY_MANAGEMENT
                Location preRl = null;
                Location nextRl = null;
//                System.out.println("当设备是: "+fogDevice.getName());
//                System.out.println("id是: "+fogDevice.getId());
                HashMap<Double, Location> temp = (HashMap<Double, Location>) locator.getDataObject().usersLocation.get(dataId);
//                for (Map.Entry<Double, Location> tt: temp.entrySet()){
//                    System.out.println("time = "+tt.getKey());
//                    System.out.println("long = "+tt.getValue().longitude);
//                    System.out.println("lati = "+tt.getValue().latitude);
//                }

                for (int i = 0; i < timeSheet.size() - 1; i++) {
//                    System.out.println("||||||||||");
                    preRl = locator.getDataObject().usersLocation.get(dataId).get(timeSheet.get(i));
//                    System.out.println("time i = "+timeSheet.get(i));
//                    System.out.println("preRl.longitude = "+preRl.longitude);
//                    System.out.println("preRl.latitude = "+preRl.latitude);
                    nextRl = locator.getDataObject().usersLocation.get(dataId).get(timeSheet.get(i+1));
//                    System.out.println("time i+1 = "+timeSheet.get(i+1));
//                    System.out.println("nextRl.longitude = "+nextRl.longitude);
//                    System.out.println("nextRl.latitude = "+nextRl.latitude);
//                    System.out.println("||||||||||");
                    if ((preRl.longitude!=nextRl.longitude) || (preRl.latitude!=nextRl.latitude)) {
                        // 如果前后两个时间的位置发生变化, 那么MOBILITY_MANAGEMENT
                        send(getId(), timeSheet.get(i+1), FogEvents.MOBILITY_MANAGEMENT, fogDevice);
                    }
                }
            }
        }
    }
    private void processMobilityData() {
        // TODO Auto-generated method stub
        List<Double> timeSheet = new ArrayList<Double>();
        for (FogDevice fogDevice : getFogDevices()) {
            if (locator.isAMobileDevice(fogDevice.getId())) {
                // timeSheet记录的是user在每个location的时间(event time)
                timeSheet = locator.getTimeSheet(fogDevice.getId());
//                System.out.println("当设备是: "+fogDevice.getName());
                Double initialTime = timeSheet.get(0);
                for (double timeEntry : timeSheet) {
//                    System.out.println("时间是: " + timeEntry);
                    // 然后在每个event time发送MOBILITY_MANAGEMENT
                    send(getId(), timeEntry, FogEvents.MOBILITY_MANAGEMENT, fogDevice);
                }
            }
        }
    }

    private void printNetworkUsageDetails() {
        System.out.println("Total network usage = " + NetworkUsageMonitor.getNetworkUsage() / Config.MAX_SIMULATION_TIME);
    }

    private FogDevice getCloud() {
        for (FogDevice dev : getFogDevices())
            if (dev.getName().equals("cloud"))
                return dev;
        return null;
    }

    private void printCostDetails() {
        System.out.println("Cost of execution in cloud = " + getCloud().getTotalCost());
    }

    private void printPowerDetails() {
        for (FogDevice fogDevice : getFogDevices()) {
            System.out.println(fogDevice.getName() + " : Energy Consumed = " + fogDevice.getEnergyConsumption());
        }
    }

    /*
    private String getStringForLoopId(int loopId){
        for(String appId : getApplications().keySet()){
            Application app = getApplications().get(appId);
            for(AppLoop loop : app.getLoops()){
                if(loop.getLoopId() == loopId)
                    return loop.getModules().toString();
            }
        }
        return null;
    }
    */
    private void printTimeDetails() {
        System.out.println("=========================================");
        System.out.println("============== RESULTS ==================");
        System.out.println("=========================================");
        System.out.println("EXECUTION TIME : " + (Calendar.getInstance().getTimeInMillis() - TimeKeeper.getInstance().getSimulationStartTime()));
        System.out.println("=========================================");
        //System.out.println("APPLICATION LOOP DELAYS");
        //System.out.println("=========================================");
        //for(Integer loopId : TimeKeeper.getInstance().getLoopIdToTupleIds().keySet()){
			/*double average = 0, count = 0;
			for(int tupleId : TimeKeeper.getInstance().getLoopIdToTupleIds().get(loopId)){
				Double startTime = 	TimeKeeper.getInstance().getEmitTimes().get(tupleId);
				Double endTime = 	TimeKeeper.getInstance().getEndTimes().get(tupleId);
				if(startTime == null || endTime == null)
					break;
				average += endTime-startTime;
				count += 1;
			}
			System.out.println(getStringForLoopId(loopId) + " ---> "+(average/count));*/
        //System.out.println(getStringForLoopId(loopId) + " ---> "+TimeKeeper.getInstance().getLoopIdToCurrentAverage().get(loopId));
        //}
        System.out.println("=========================================");
        System.out.println("TUPLE CPU EXECUTION DELAY");
        System.out.println("=========================================");

        for (String tupleType : TimeKeeper.getInstance().getTupleTypeToAverageCpuTime().keySet()) {
            System.out.println(tupleType + " ---> " + TimeKeeper.getInstance().getTupleTypeToAverageCpuTime().get(tupleType));
        }

        System.out.println("=========================================");
        System.out.println("=========================================");
        System.out.println("LATENCY AND MIGRATING TIME FOR EACH MOBILE USER");
        System.out.println("--------------------------------");
        HashMap<Double, Double> latencyAndDelay = new HashMap<>();
        latencyAndDelay = calculateAverageLatencyDelay();
        System.out.println("--------------------------------");
        System.out.println("AVERAGE LATENCY AND AVERAGE MIGRATING TIME FOR EACH MOBILE USER");
        System.out.println("--------------------------------");
        System.out.println("Average Latency = "+latencyAndDelay.entrySet().iterator().next().getKey());
        System.out.println("Average Migrating time = "+latencyAndDelay.entrySet().iterator().next().getValue());
        System.out.println("=========================================");
    }
    private HashMap<Double, Double> calculateAverageLatencyDelay(){
        HashMap<Double, Double> latencyDelayMap = calculateLatencyAndDelayHelper();
        double resultLatency = latencyDelayMap.entrySet().iterator().next().getKey();
        double resultDelay = latencyDelayMap.entrySet().iterator().next().getValue();
        int numOfMobile = locator.getDataObject().usersLocation.size();
        System.out.println("--------------------------------");
        System.out.println("TOTAL LATENCY AND TOTAL MIGRATING TIME FOR EACH MOBILE USER");
        System.out.println("--------------------------------");
        System.out.println("total latency = "+resultLatency);
        System.out.println("total migrating time = "+resultDelay);
        System.out.println("numOfMobile = "+numOfMobile);
        resultLatency /= numOfMobile;
        resultDelay /= numOfMobile;
        HashMap<Double, Double> result = new HashMap<>();
        result.put(resultLatency, resultDelay);
        return result;
    }
    private HashMap<Double, Double> calculateLatencyAndDelayHelper(){
        double resultDelay = 0.0;
        double resultLatency = 0.0;
        HashMap<Double, Double> latencyDelayMap = new HashMap<>();
        HashMap<FogDevice, Double> userEventTimeMap = new HashMap<>();
        FogDevice mobile = null;
        for (String dataId : locator.getDataIdsLevelReferences().keySet()) {
            // getInstenceDataIdReferences stores all fogDevices, including one user,
            // one cloud, all proxy servers and gateWays and their mobile.getId()(key)
            Map<Double, Location> tempUserLocationInfo = new HashMap<Double, Location>();
            for (int instenceId : locator.getInstenceDataIdReferences().keySet()) {
                if (locator.getInstenceDataIdReferences().get(instenceId).equals(dataId)) {
                    FogDevice fogDevice = getFogDeviceById(instenceId);
                    mobile = fogDevice;
                    if (fogDevice.getName().contains("mobile")){
//                        System.out.println("dataId = "+dataId);
                        tempUserLocationInfo = locator.getDataObject().usersLocation.get(dataId);
//                        System.out.println("instenceId = "+instenceId);
//                        System.out.println("fogDevice = "+fogDevice.getName());
                    }

                }
            }
            Iterator<Map.Entry<Double, Location>> iterator = tempUserLocationInfo.entrySet().iterator();
            if (iterator.hasNext()) {
                iterator.next();
                if (iterator.hasNext()) {
                    Map.Entry<Double, Location> secondEntry = iterator.next();
                    userEventTimeMap.put(mobile, secondEntry.getKey());
                }
            }
        }
//        int numOfMobile = 0;
        for (FogDevice fogDevice : getFogDevices()) {
            if (fogDevice.getName().contains("mobile")){
//                numOfMobile ++;
//                System.out.println("name = "+fogDevice.getName());
                FogDevice parent = getFogDeviceById(parentReference.get(fogDevice.getId()));
//                System.out.println("parent = "+parent.getName());
                double latency = calculateLatencyHelper(parent, fogDevice, userEventTimeMap.get(fogDevice));

                //                double latency = fogDevice.getUplinkLatency();
                System.out.println("Child " + fogDevice.getName() + "("+fogDevice.getId()+")"+"\t----->\tParent " + parent.getName());
                System.out.println("latency = "+latency);
                if (!moduleMigratingDelay.containsKey(fogDevice)){
                    System.out.println("migrating time = 0");
                } else {
                    System.out.println("migrating time = "+moduleMigratingDelay.get(fogDevice));
                    resultDelay += moduleMigratingDelay.get(fogDevice);
                }

                resultLatency += latency;
            }
        }
        latencyDelayMap.put(resultLatency, resultDelay);
        return latencyDelayMap;
    }

    private Double calculateLatencyHelper(FogDevice parent, FogDevice mobile, double time){
        String applicationNameTemp = parent.getActiveApplications().get(0);
        ModulePlacementMobileEdgewardsCluster modulePlacementMobileEdgewardsCluster = (ModulePlacementMobileEdgewardsCluster)getAppModulePlacementPolicy().get(applicationNameTemp);
        double cpuLoadOccupied = modulePlacementMobileEdgewardsCluster.getCurrentCpuLoad().get(parent.getId());
        long sizeOccupied = 1000000 - parent.getHost().getStorage();
        int ramOccupied = parent.getHost().getRam() - parent.getHost().getRamProvisioner().getAvailableRam();
        long bwOccupied = parent.getHost().getBw() - parent.getHost().getBwProvisioner().getAvailableBw();
        return locator.calculateLatencyOfNode(parent, mobile, time, cpuLoadOccupied, sizeOccupied, ramOccupied, bwOccupied);
    }
    protected void manageResources() {
        send(getId(), Config.RESOURCE_MANAGE_INTERVAL, FogEvents.CONTROLLER_RESOURCE_MANAGE);
    }

    private void processTupleFinished(SimEvent ev) {
    }

    @Override
    public void shutdownEntity() {
    }

    public void submitApplication(Application application, int delay, ModulePlacement modulePlacement) {
        FogUtils.appIdToGeoCoverageMap.put(application.getAppId(), application.getGeoCoverage());
        getApplications().put(application.getAppId(), application);
        getAppLaunchDelays().put(application.getAppId(), delay);
        getAppModulePlacementPolicy().put(application.getAppId(), modulePlacement);


        // link sensor with its application
        for (Sensor sensor : sensors) {
            sensor.setApp(getApplications().get(sensor.getAppId()));
        }
        //link actuator with its application
        for (Actuator ac : actuators) {
            ac.setApp(getApplications().get(ac.getAppId()));
        }


        for (AppEdge edge : application.getEdges()) {
            if (edge.getEdgeType() == AppEdge.ACTUATOR) {
                String moduleName = edge.getSource();
                for (Actuator actuator : getActuators()) {
                    if (actuator.getActuatorType().equalsIgnoreCase(edge.getDestination()))
                        application.getModuleByName(moduleName).subscribeActuator(actuator.getId(), edge.getTupleType());
                }
            }
        }
    }

    public void submitApplication(Application application, ModulePlacement modulePlacement) {
        submitApplication(application, 0, modulePlacement);
    }


    private void processAppSubmit(SimEvent ev) {
        Application app = (Application) ev.getData();
        processAppSubmit(app);
    }

    private void processAppSubmit(Application application) {
        System.out.println(CloudSim.clock() + " Submitted application " + application.getAppId());
        FogUtils.appIdToGeoCoverageMap.put(application.getAppId(), application.getGeoCoverage());

        getApplications().put(application.getAppId(), application);

        ModulePlacement modulePlacement = getAppModulePlacementPolicy().get(application.getAppId());
        for (FogDevice fogDevice : fogDevices) {
            sendNow(fogDevice.getId(), FogEvents.ACTIVE_APP_UPDATE, application);
        }

        Map<Integer, List<AppModule>> deviceToModuleMap = modulePlacement.getDeviceToModuleMap();
        for (Integer deviceId : deviceToModuleMap.keySet()) {
            for (AppModule module : deviceToModuleMap.get(deviceId)) {
                // 将 application 发送到 目前这个device上
                sendNow(deviceId, FogEvents.APP_SUBMIT, application);
//                sendNow(deviceId, FogEvents.LAUNCH_MODULE, module);
            }
        }
    }

    public List<FogDevice> getFogDevices() {
        return fogDevices;
    }

    public void setFogDevices(List<FogDevice> fogDevices) {
        this.fogDevices = fogDevices;
    }

    public Map<String, Integer> getAppLaunchDelays() {
        return appLaunchDelays;
    }

    public void setAppLaunchDelays(Map<String, Integer> appLaunchDelays) {
        this.appLaunchDelays = appLaunchDelays;
    }

    public Map<String, Application> getApplications() {
        return applications;
    }

    public void setApplications(Map<String, Application> applications) {
        this.applications = applications;
    }

    public List<Sensor> getSensors() {
        return sensors;
    }

    public void setSensors(List<Sensor> sensors) {
        for (Sensor sensor : sensors)
            sensor.setControllerId(getId());
        this.sensors = sensors;
    }

    public List<Actuator> getActuators() {
        return actuators;
    }

    public void setActuators(List<Actuator> actuators) {
        this.actuators = actuators;
    }

    public Map<String, ModulePlacement> getAppModulePlacementPolicy() {
        return appModulePlacementPolicy;
    }

    public void setAppModulePlacementPolicy(Map<String, ModulePlacement> appModulePlacementPolicy) {
        this.appModulePlacementPolicy = appModulePlacementPolicy;
    }

    public LocationHandler getLocator() {
        return locator;
    }

    public void setLocator(LocationHandler locator) {
        this.locator = locator;
    }
    public void setAlgorithmType(int algorithmType) {
        this.algorithmType = algorithmType;
    }
}






